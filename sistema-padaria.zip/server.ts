import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy-initialized GoogleGenAI
let aiClient: GoogleGenAI | null = null;
function getAIClient(): GoogleGenAI | null {
  if (!aiClient && process.env.GEMINI_API_KEY) {
    aiClient = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  }
  return aiClient;
}

// Gemini AI Assistant Endpoint for Bakery Suggestions
app.post('/api/ai/bakery-advisor', async (req, res) => {
  try {
    const { prompt, type, contextData } = req.body;
    const ai = getAIClient();

    if (!ai) {
      // Fallback smart responses in Portuguese if GEMINI_API_KEY is not configured yet
      return res.json({
        success: true,
        source: 'local_expert',
        reply: getLocalExpertBakeryAdvice(type, prompt, contextData),
      });
    }

    const systemInstruction = `Você é o "Mestre Padeiro IA", um consultor especialista e mestre de panificação artesanal e gestão financeira de padarias no Brasil.
Seu objetivo é ajudar donos, padeiros e gerentes a otimizar:
1. Programação e cálculo de fornadas (evitando falta de pão francês nos horários de pico 06:30-08:30 e 16:30-19:00).
2. Redução de desperdício e perdas de pães dormidos (transformando sobras em torradas temperadas, pudim de pão, farinha de rosca e croutons).
3. Precificação e cálculo de CMV (Custo de Mercadoria Vendida) com margens ideais (pães 60-70%, confeitaria 65-75%).
4. Dicas de fermentação, temperatura de forno e combinação de combos (ex: Pingado + Pão na Chapa).

Responda sempre em português do Brasil com formatação limpa (Markdown, tópicos claros, emojis moderados e sugestões práticas e diretas).`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: `${systemInstruction}\n\nContexto da Padaria Atual: ${JSON.stringify(contextData || {})}\n\nPergunta/Solicitação do Usuário:\n${prompt}`,
            },
          ],
        },
      ],
    });

    const reply = response.text || 'Não foi possível gerar a sugestão no momento.';
    return res.json({
      success: true,
      source: 'gemini',
      reply,
    });
  } catch (error: unknown) {
    console.error('AI error:', error);
    const errorMessage = error instanceof Error ? error.message : 'Erro ao processar consulta com IA.';
    return res.status(500).json({
      success: false,
      error: errorMessage,
    });
  }
});

function getLocalExpertBakeryAdvice(type: string, prompt: string, contextData: any): string {
  if (type === 'fornadas') {
    return `### 🥖 Recomendação de Fornadas para Hoje:

1. **Pico da Tarde (16:30 - 18:30)**:
   - **Pão Francês**: Programar fornada de **200 unidades** para sair às **16:45** e outra de **150 unidades** às **17:45**.
   - **Pão de Queijo**: Assar **80 unidades** às **16:30** para acompanhar o café da tarde.
   - **Croissant e Folhados**: Aquecer 25 unidades na estufa vitrine.

2. **Dica Técnica do Mestre**:
   - Mantenha o vapor do forno a 220°C por 15 segundos no início da fornada do Pão Francês para garantir a casca estaladiça e o miolo aerado.
   - Ponto de fermentação ideal: 85% de crescimento antes de cortar a pestana.`;
  }

  if (type === 'desperdicio') {
    return `### ♻️ Plano de Reaproveitamento de Pães & Sobras:

1. **Torradas Finas com Ervas Finas e Azeite**:
   - Fatiar o Pão Francês dormido em fatias de 5mm, pincelar azeite com orégano e assar a 140°C até dourar. Margem de lucro: **85%**.

2. **Farinha de Rosca Artesanal Panko/Tradicional**:
   - Secar os pães ao forno brando e triturar no moedor. Embalar em saquinhos de 500g a R$ 6,90 cada.

3. **Pudim de Pão com Caramelo e Canela**:
   - Transforma pães dormidos e leite em uma das sobremesas mais vendidas da confeitaria com custo quase nulo de matéria-prima.`;
  }

  return `### 💡 Análise de Gestão da Padaria:
- **Horários de Maior Movimento**: 06:30 às 09:00 e 16:30 às 19:30.
- **Sugestão de Combo do Dia**: *Pão na Chapa com Manteiga Especial + Café Pingado*. Preço sugerido: **R$ 11,90** (Margem estimada de 68%).
- **Controle de Insumos**: Fermento fresco e farinha de trigo especial devem ser monitorados diariamente para evitar paradas na produção.`;
}

// Vite middleware or static serving
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Sistema Padaria rodando na porta ${PORT}`);
  });
}

startServer();
