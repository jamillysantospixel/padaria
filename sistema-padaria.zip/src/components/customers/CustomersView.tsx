import React, { useState } from 'react';
import { useBakery } from '../../context/BakeryContext';
import { 
  Users, Plus, Search, BookOpen, Star, DollarSign, 
  Phone, Mail, Check, X, ArrowUpRight, MessageCircle 
} from 'lucide-react';
import { formatCurrency, formatDateTime } from '../../lib/formatters';
import { Customer } from '../../types';

export const CustomersView: React.FC = () => {
  const { customers, addCustomer, updateCustomer, payCustomerDebt } = useBakery();
  const [searchQuery, setSearchQuery] = useState('');

  // Pay Debt Modal
  const [payingCustomer, setPayingCustomer] = useState<Customer | null>(null);
  const [payAmount, setPayAmount] = useState<number>(0);

  // New Customer Modal
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [newCustomer, setNewCustomer] = useState({
    name: '',
    phone: '',
    email: '',
    cpf: '',
    creditLimit: 200.0,
    notes: '',
  });

  const filteredCustomers = customers.filter((c) =>
    c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.phone.includes(searchQuery) ||
    (c.cpf && c.cpf.includes(searchQuery))
  );

  const totalOutstandingCredit = customers.reduce((acc, c) => acc + c.creditBalance, 0);
  const totalLoyaltyPoints = customers.reduce((acc, c) => acc + c.loyaltyPoints, 0);

  const handleOpenPayDebt = (c: Customer) => {
    setPayingCustomer(c);
    setPayAmount(c.creditBalance);
  };

  const handleConfirmPayDebt = (e: React.FormEvent) => {
    e.preventDefault();
    if (payingCustomer && payAmount > 0) {
      payCustomerDebt(payingCustomer.id, payAmount);
      setPayingCustomer(null);
    }
  };

  const handleCreateCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    addCustomer(newCustomer);
    setIsAddOpen(false);
    setNewCustomer({
      name: '',
      phone: '',
      email: '',
      cpf: '',
      creditLimit: 200.0,
      notes: '',
    });
  };

  return (
    <div id="customers-view" className="space-y-6">
      {/* Top Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs">
          <span className="text-xs font-bold text-stone-500 uppercase tracking-wider">
            Total a Receber (Fiado / Caderneta)
          </span>
          <p className="text-2xl font-extrabold text-amber-700 font-['Outfit'] mt-1">
            {formatCurrency(totalOutstandingCredit)}
          </p>
          <p className="text-xs text-stone-500 mt-1">
            Saldo devedor somado de todos os clientes
          </p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs">
          <span className="text-xs font-bold text-stone-500 uppercase tracking-wider">
            Programa de Fidelidade
          </span>
          <p className="text-2xl font-extrabold text-emerald-700 font-['Outfit'] mt-1">
            {totalLoyaltyPoints} pts
          </p>
          <p className="text-xs text-stone-500 mt-1">
            Pontos acumulados para resgate de pães e café
          </p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-stone-500 uppercase tracking-wider">
              Clientes Cadastrados
            </span>
            <p className="text-xs text-stone-600 mt-1">{customers.length} cadastros ativos</p>
          </div>
          <button
            id="btn-add-customer"
            onClick={() => setIsAddOpen(true)}
            className="px-4 py-2.5 bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center gap-1.5 shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Novo Cliente</span>
          </button>
        </div>
      </div>

      {/* Search Header */}
      <div className="bg-white p-4 rounded-3xl border border-stone-200 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-96">
          <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Buscar por nome, telefone ou CPF..."
            className="w-full pl-10 pr-4 py-2 rounded-xl bg-stone-50 border border-stone-200 text-stone-900 text-xs focus:outline-none focus:border-amber-500"
          />
        </div>
      </div>

      {/* Customers Table */}
      <div className="bg-white rounded-3xl border border-stone-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-stone-700">
            <thead className="bg-stone-50 border-b border-stone-200 font-bold uppercase text-stone-500 tracking-wider">
              <tr>
                <th className="py-3 px-4">Cliente</th>
                <th className="py-3 px-4">Contato / CPF</th>
                <th className="py-3 px-4 text-center">Fidelidade</th>
                <th className="py-3 px-4 text-right">Limite Fiado</th>
                <th className="py-3 px-4 text-right">Saldo Devedor</th>
                <th className="py-3 px-4 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {filteredCustomers.map((cust) => {
                const hasDebt = cust.creditBalance > 0;

                return (
                  <tr key={cust.id} className="hover:bg-amber-50/30 transition-colors">
                    <td className="py-3 px-4">
                      <div>
                        <p className="font-bold text-stone-900 leading-snug">{cust.name}</p>
                        {cust.notes && (
                          <p className="text-[11px] text-stone-400 truncate max-w-xs">{cust.notes}</p>
                        )}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <p className="font-mono text-stone-800">{cust.phone}</p>
                      <p className="text-[10px] text-stone-400 font-mono">{cust.cpf || 'Sem CPF'}</p>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span className="px-2.5 py-1 rounded-full bg-amber-50 border border-amber-200 text-amber-900 font-mono font-bold text-[11px] inline-flex items-center gap-1">
                        <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
                        <span>{cust.loyaltyPoints} pts</span>
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right font-mono text-stone-600">
                      {formatCurrency(cust.creditLimit)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold">
                      <span
                        className={`px-2.5 py-1 rounded-full text-[11px] ${
                          hasDebt
                            ? 'bg-rose-100 text-rose-800 border border-rose-200'
                            : 'bg-stone-100 text-stone-600'
                        }`}
                      >
                        {formatCurrency(cust.creditBalance)}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {hasDebt && (
                          <button
                            id={`btn-pay-debt-${cust.id}`}
                            onClick={() => handleOpenPayDebt(cust)}
                            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-[11px] transition-colors shadow-xs"
                          >
                            Receber Fiado
                          </button>
                        )}

                        <a
                          href={`https://wa.me/55${cust.phone.replace(/\D/g, '')}`}
                          target="_blank"
                          rel="noreferrer"
                          className="p-1.5 rounded-xl border border-stone-200 hover:bg-emerald-50 text-emerald-700 transition-colors"
                          title="Enviar WhatsApp"
                        >
                          <MessageCircle className="w-4 h-4" />
                        </a>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pay Debt Modal */}
      {payingCustomer && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 space-y-5 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div>
                <h3 className="font-bold text-base text-stone-900 font-['Outfit']">
                  Receber Pagamento de Fiado
                </h3>
                <p className="text-xs text-stone-500">{payingCustomer.name}</p>
              </div>
              <button
                onClick={() => setPayingCustomer(null)}
                className="p-1 rounded-lg text-stone-400 hover:text-stone-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleConfirmPayDebt} className="space-y-4">
              <div className="p-4 bg-amber-50 rounded-2xl border border-amber-200 space-y-1 text-xs">
                <div className="flex justify-between text-amber-900">
                  <span>Dívida Atual em Aberto:</span>
                  <strong className="font-mono text-sm">{formatCurrency(payingCustomer.creditBalance)}</strong>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Valor a Pagar / Amortizar (R$) *
                </label>
                <input
                  type="number"
                  step="0.50"
                  required
                  min="0.50"
                  max={payingCustomer.creditBalance}
                  value={payAmount}
                  onChange={(e) => setPayAmount(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 text-base font-mono font-bold rounded-xl border border-emerald-300 focus:border-emerald-500 focus:outline-none"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setPayingCustomer(null)}
                  className="flex-1 py-2.5 rounded-xl border border-stone-300 text-stone-700 font-bold text-xs hover:bg-stone-100"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md"
                >
                  Confirmar Recebimento
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Customer Modal */}
      {isAddOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 space-y-5 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <h3 className="font-bold text-base text-stone-900 font-['Outfit']">
                Cadastrar Novo Cliente
              </h3>
              <button
                onClick={() => setIsAddOpen(false)}
                className="p-1 rounded-lg text-stone-400 hover:text-stone-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateCustomer} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Nome Completo *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Dona Maria Aparecida"
                  value={newCustomer.name}
                  onChange={(e) => setNewCustomer({ ...newCustomer, name: e.target.value })}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-stone-200 focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    WhatsApp / Telefone *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="(11) 99999-8888"
                    value={newCustomer.phone}
                    onChange={(e) => setNewCustomer({ ...newCustomer, phone: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-stone-200 focus:border-amber-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    CPF (Opcional)
                  </label>
                  <input
                    type="text"
                    placeholder="000.000.000-00"
                    value={newCustomer.cpf}
                    onChange={(e) => setNewCustomer({ ...newCustomer, cpf: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-stone-200 focus:border-amber-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Limite de Crédito Fiado (R$)
                </label>
                <input
                  type="number"
                  step="50"
                  value={newCustomer.creditLimit}
                  onChange={(e) => setNewCustomer({ ...newCustomer, creditLimit: parseFloat(e.target.value) || 0 })}
                  className="w-full px-3 py-2 text-xs font-mono rounded-xl border border-stone-200 focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Observações / Preferências
                </label>
                <textarea
                  rows={2}
                  placeholder="Gosta do pão francês mais branquinho, cafezinho sem açúcar..."
                  value={newCustomer.notes}
                  onChange={(e) => setNewCustomer({ ...newCustomer, notes: e.target.value })}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-stone-200 focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddOpen(false)}
                  className="flex-1 py-2.5 rounded-xl border border-stone-300 text-stone-700 font-bold text-xs hover:bg-stone-100"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs shadow-md"
                >
                  Salvar Cliente
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
