import React from 'react';
import { useBakery } from '../../context/BakeryContext';
import { 
  LayoutDashboard, ShoppingBag, Package, ShoppingCart, 
  Flame, DollarSign, Users, UserCheck, BarChart3, 
  Sparkles, LogOut, Store, ChevronRight, AlertCircle, Clock
} from 'lucide-react';

export type NavigationTab = 
  | 'dashboard' 
  | 'pdv' 
  | 'produtos' 
  | 'estoque' 
  | 'fornadas' 
  | 'caixa' 
  | 'clientes' 
  | 'funcionarios' 
  | 'relatorios'
  | 'ia-assistente';

interface SidebarProps {
  activeTab: NavigationTab;
  setActiveTab: (tab: NavigationTab) => void;
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
  openAiModal: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  isOpen,
  openAiModal,
}) => {
  const { currentUser, logout, cashRegister, batches, products, ingredients } = useBakery();

  // Low stock count
  const lowStockCount = [
    ...products.filter((p) => p.stock <= p.minStock),
    ...ingredients.filter((i) => i.currentStock <= i.minStock),
  ].length;

  // Active batches in oven/prep
  const activeBatchesCount = batches.filter(
    (b) => b.status === 'assando' || b.status === 'fermentando' || b.status === 'preparando'
  ).length;

  const navItems: { id: NavigationTab; label: string; icon: React.ComponentType<{ className?: string }>; badge?: number; badgeColor?: string }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'pdv', label: 'Frente de Caixa (PDV)', icon: ShoppingCart },
    { id: 'produtos', label: 'Produtos & Cardápio', icon: ShoppingBag },
    { id: 'estoque', label: 'Estoque & Insumos', icon: Package, badge: lowStockCount > 0 ? lowStockCount : undefined, badgeColor: 'bg-rose-500 text-white' },
    { id: 'fornadas', label: 'Fornadas & Produção', icon: Flame, badge: activeBatchesCount > 0 ? activeBatchesCount : undefined, badgeColor: 'bg-amber-500 text-white' },
    { id: 'caixa', label: 'Controle de Caixa', icon: DollarSign },
    { id: 'clientes', label: 'Clientes & Fiado', icon: Users },
    { id: 'funcionarios', label: 'Funcionários', icon: UserCheck },
    { id: 'relatorios', label: 'Relatórios & DRE', icon: BarChart3 },
  ];

  return (
    <aside
      id="main-sidebar"
      className={`fixed top-0 left-0 bottom-0 z-40 bg-stone-900 text-stone-100 flex flex-col border-r border-stone-800 transition-all duration-300 ${
        isOpen ? 'w-64' : 'w-20'
      }`}
    >
      {/* Brand Header */}
      <div className="p-4 border-b border-stone-800 flex items-center justify-between">
        <div className="flex items-center gap-3 overflow-hidden">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-amber-700 flex items-center justify-center text-white shadow-md shadow-amber-950 shrink-0">
            <Store className="w-6 h-6" />
          </div>
          {isOpen && (
            <div className="flex flex-col min-w-0">
              <span className="font-extrabold text-base tracking-tight text-white font-['Outfit'] truncate">
                Sistema Padaria
              </span>
              <span className="text-[11px] text-amber-400 font-medium">Gestão & PDV</span>
            </div>
          )}
        </div>
      </div>

      {/* Caixa Status Indicator */}
      {isOpen && (
        <div className="px-4 py-3 bg-stone-950/60 border-b border-stone-800/80">
          <div className="flex items-center justify-between text-xs">
            <span className="text-stone-400 flex items-center gap-1.5">
              <span className={`w-2 h-2 rounded-full ${cashRegister.status === 'aberto' ? 'bg-emerald-500 animate-pulse' : 'bg-stone-500'}`} />
              Status do Caixa:
            </span>
            <span className={`font-semibold px-2 py-0.5 rounded text-[10px] uppercase tracking-wider ${
              cashRegister.status === 'aberto' ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-800/60' : 'bg-stone-800 text-stone-300'
            }`}>
              {cashRegister.status === 'aberto' ? 'Aberto' : 'Fechado'}
            </span>
          </div>
        </div>
      )}

      {/* Navigation Links */}
      <div className="flex-1 py-4 px-3 space-y-1 overflow-y-auto custom-scrollbar">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              id={`nav-link-${item.id}`}
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl font-medium text-sm transition-all duration-150 group relative ${
                isActive
                  ? 'bg-amber-500 text-white shadow-md shadow-amber-950/50 font-semibold'
                  : 'text-stone-400 hover:text-stone-100 hover:bg-stone-800/70'
              }`}
              title={!isOpen ? item.label : undefined}
            >
              <Icon className={`w-5 h-5 shrink-0 ${isActive ? 'text-white' : 'text-stone-400 group-hover:text-stone-200'}`} />
              
              {isOpen && (
                <span className="truncate flex-1 text-left">{item.label}</span>
              )}

              {item.badge !== undefined && (
                <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full shrink-0 ${item.badgeColor || 'bg-amber-500 text-white'}`}>
                  {item.badge}
                </span>
              )}

              {isOpen && isActive && (
                <ChevronRight className="w-4 h-4 text-white/70 ml-auto shrink-0" />
              )}
            </button>
          );
        })}

        {/* AI Assistant Quick Trigger */}
        <div className="pt-2">
          <button
            id="nav-link-ai-assistant"
            onClick={openAiModal}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl font-medium text-sm transition-all duration-150 bg-gradient-to-r from-amber-600/30 to-amber-700/20 border border-amber-500/30 text-amber-300 hover:bg-amber-500/20 hover:border-amber-400/50 group`}
            title="Mestre Padeiro IA"
          >
            <Sparkles className="w-5 h-5 text-amber-400 shrink-0 animate-pulse" />
            {isOpen && (
              <span className="truncate flex-1 text-left font-semibold">
                Mestre Padeiro IA
              </span>
            )}
            {isOpen && (
              <span className="text-[9px] bg-amber-400/20 border border-amber-400/40 text-amber-300 font-bold px-1.5 py-0.5 rounded uppercase">
                Gemini
              </span>
            )}
          </button>
        </div>
      </div>

      {/* User Profile / Logout Footer */}
      {currentUser && (
        <div className="p-3 border-t border-stone-800 bg-stone-950/40">
          <div className="flex items-center gap-3 p-2 rounded-xl bg-stone-900 border border-stone-800">
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-9 h-9 rounded-lg object-cover border border-amber-500/40 shrink-0"
            />
            {isOpen && (
              <div className="flex-1 min-w-0">
                <p className="text-xs font-bold text-white truncate">{currentUser.name}</p>
                <p className="text-[10px] text-amber-400 capitalize truncate">
                  {currentUser.role === 'admin' ? 'Administrador' : currentUser.role === 'padeiro' ? 'Padeiro Chefe' : currentUser.role === 'caixa' ? 'Operador Caixa' : 'Gerente'}
                </p>
              </div>
            )}
            <button
              id="btn-logout"
              onClick={logout}
              className="p-1.5 text-stone-400 hover:text-rose-400 hover:bg-rose-950/30 rounded-lg transition-colors"
              title="Trocar de Usuário / Sair"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </aside>
  );
};
