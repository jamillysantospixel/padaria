import React, { useState, useEffect } from 'react';
import { useBakery } from '../../context/BakeryContext';
import { NavigationTab } from './Sidebar';
import { 
  Menu, ShoppingCart, Flame, DollarSign, Bell, 
  RotateCcw, Sparkles, User as UserIcon, Check, ChevronDown 
} from 'lucide-react';
import { formatCurrency } from '../../lib/formatters';

interface HeaderProps {
  activeTab: NavigationTab;
  setActiveTab: (tab: NavigationTab) => void;
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
  openAiModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  sidebarOpen,
  setSidebarOpen,
  openAiModal,
}) => {
  const { currentUser, users, loginAs, cashRegister, batches, resetDemoData } = useBakery();
  const [timeStr, setTimeStr] = useState('');
  const [dateStr, setDateStr] = useState('');
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(now.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
      setDateStr(now.toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'short' }));
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const titles: Record<NavigationTab, { title: string; subtitle: string }> = {
    dashboard: { title: 'Painel Geral', subtitle: 'Métricas, vendas do dia e fornadas em tempo real' },
    pdv: { title: 'Frente de Caixa (PDV)', subtitle: 'Emissão rápida de vendas, pesagem e recebimentos' },
    produtos: { title: 'Catálogo de Produtos', subtitle: 'Cardápio, precificação, fichas e margem de lucro' },
    estoque: { title: 'Controle de Estoque & Insumos', subtitle: 'Matérias-primas, lotes, validade e reposições' },
    fornadas: { title: 'Fornadas & Produção', subtitle: 'Planejamento de produção, fornos e controle de perdas' },
    caixa: { title: 'Controle de Caixa', subtitle: 'Abertura, sangrias, suprimentos e fechamento de turno' },
    clientes: { title: 'Clientes & Caderneta', subtitle: 'Controle de fiado, histórico e programa de fidelidade' },
    funcionarios: { title: 'Quadro de Funcionários', subtitle: 'Escalas de trabalho, turnos, funções e equipe' },
    relatorios: { title: 'Relatórios & DRE', subtitle: 'Faturamento, demonstrativo financeiro e curva ABC' },
    'ia-assistente': { title: 'Mestre Padeiro IA', subtitle: 'Inteligência Artificial para otimização da padaria' },
  };

  // Recent ready batch
  const latestReadyBatch = batches.find((b) => b.status === 'pronto');

  return (
    <header id="main-header" className="bg-white border-b border-stone-200 sticky top-0 z-30 shadow-xs">
      <div className="px-4 sm:px-6 py-3 flex items-center justify-between gap-4">
        {/* Left Side: Toggle & Title */}
        <div className="flex items-center gap-3 min-w-0">
          <button
            id="btn-toggle-sidebar"
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-2 rounded-xl text-stone-600 hover:bg-stone-100 hover:text-stone-900 transition-colors"
            title="Recolher / Expandir Menu"
          >
            <Menu className="w-5 h-5" />
          </button>

          <div className="min-w-0">
            <h1 className="text-lg font-bold text-stone-900 tracking-tight leading-tight truncate font-['Outfit']">
              {titles[activeTab]?.title || 'Sistema Padaria'}
            </h1>
            <p className="text-xs text-stone-500 hidden sm:block truncate">
              {titles[activeTab]?.subtitle}
            </p>
          </div>
        </div>

        {/* Center: Fresh Bread Alert Banner (if ready) */}
        {latestReadyBatch && (
          <button
            id="banner-fresh-bread"
            onClick={() => setActiveTab('fornadas')}
            className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-full bg-amber-100 border border-amber-300 text-amber-900 text-xs font-semibold hover:bg-amber-200 transition-colors animate-pulse"
          >
            <Flame className="w-4 h-4 text-amber-600" />
            <span>Fornada Quentinha: {latestReadyBatch.productName}!</span>
          </button>
        )}

        {/* Right Side: Quick Action Buttons & User Switch */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* Quick Sale / PDV Button */}
          <button
            id="btn-quick-sale"
            onClick={() => setActiveTab('pdv')}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all shadow-xs ${
              activeTab === 'pdv'
                ? 'bg-amber-600 text-white'
                : 'bg-amber-500 hover:bg-amber-600 text-white'
            }`}
          >
            <ShoppingCart className="w-4 h-4" />
            <span className="hidden sm:inline">Nova Venda</span>
          </button>

          {/* Quick Batch Button */}
          <button
            id="btn-quick-batch"
            onClick={() => setActiveTab('fornadas')}
            className="hidden lg:flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-stone-100 hover:bg-stone-200 text-stone-700 transition-colors border border-stone-200"
          >
            <Flame className="w-4 h-4 text-amber-600" />
            <span>Fornadas</span>
          </button>

          {/* AI Advisor Button */}
          <button
            id="btn-quick-ai"
            onClick={openAiModal}
            className="p-2 rounded-xl bg-amber-50 hover:bg-amber-100 border border-amber-200 text-amber-700 transition-colors"
            title="Abrir Assistente Inteligente IA"
          >
            <Sparkles className="w-4 h-4 text-amber-600" />
          </button>

          {/* Reset Demo Data Button */}
          <button
            id="btn-reset-demo"
            onClick={() => {
              if (confirm('Deseja restaurar todos os dados de demonstração da padaria?')) {
                resetDemoData();
              }
            }}
            className="p-2 rounded-xl text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition-colors"
            title="Restaurar dados de teste padrão"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          {/* Clock Badge */}
          <div className="hidden xl:flex flex-col text-right pl-2 border-l border-stone-200">
            <span className="text-xs font-mono font-bold text-stone-800">{timeStr}</span>
            <span className="text-[10px] text-stone-500 capitalize">{dateStr}</span>
          </div>

          {/* User Quick Switcher Dropdown */}
          <div className="relative">
            <button
              id="btn-user-switcher"
              onClick={() => setUserDropdownOpen(!userDropdownOpen)}
              className="flex items-center gap-2 p-1.5 sm:px-2.5 sm:py-1.5 rounded-xl border border-stone-200 hover:border-stone-300 bg-stone-50 hover:bg-stone-100 transition-colors"
            >
              <img
                src={currentUser?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150'}
                alt="Avatar"
                className="w-7 h-7 rounded-lg object-cover border border-amber-500/50"
              />
              <span className="text-xs font-semibold text-stone-800 hidden md:inline max-w-[90px] truncate">
                {currentUser?.name.split(' ')[0]}
              </span>
              <ChevronDown className="w-3.5 h-3.5 text-stone-400" />
            </button>

            {userDropdownOpen && (
              <div
                id="user-dropdown-menu"
                className="absolute right-0 mt-2 w-64 bg-white rounded-2xl border border-stone-200 shadow-xl py-2 z-50 animate-in fade-in zoom-in-95 duration-100"
              >
                <div className="px-3 py-2 border-b border-stone-100">
                  <p className="text-[11px] uppercase tracking-wider font-bold text-stone-400">
                    Alternar Usuário de Teste
                  </p>
                </div>
                <div className="py-1">
                  {users.map((u) => {
                    const isSelected = currentUser?.id === u.id;
                    return (
                      <button
                        key={u.id}
                        id={`switch-user-${u.id}`}
                        onClick={() => {
                          loginAs(u);
                          setUserDropdownOpen(false);
                        }}
                        className={`w-full flex items-center gap-2.5 px-3 py-2 text-left hover:bg-amber-50/70 transition-colors ${
                          isSelected ? 'bg-amber-50 text-amber-900 font-semibold' : 'text-stone-700'
                        }`}
                      >
                        <img
                          src={u.avatar}
                          alt={u.name}
                          className="w-7 h-7 rounded-lg object-cover shrink-0"
                        />
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-bold leading-tight truncate">{u.name}</p>
                          <p className="text-[10px] text-stone-500 uppercase tracking-wide">
                            {u.role} • {u.shift?.split(' ')[0] || 'Geral'}
                          </p>
                        </div>
                        {isSelected && <Check className="w-4 h-4 text-amber-600 shrink-0" />}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
