import React, { useState } from 'react';
import { Sparkles, X, Send, Bot, CheckCircle2, Flame, TrendingUp, AlertTriangle, Lightbulb, Package } from 'lucide-react';
import { useBakery } from '../../context/BakeryContext';
import { formatCurrency } from '../../lib/formatters';

interface AiAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AiAssistantModal: React.FC<AiAssistantModalProps> = ({ isOpen, onClose }) => {
  const { products, ingredients, batches, sales, cashRegister } = useBakery();
  const [messages, setMessages] = useState<Array<{ role: 'user' | 'assistant'; text: string; time: string }>>([
    {
      role: 'assistant',
      text: 'Olá! Sou o seu Mestre Padeiro & Consultor Inteligente. Como posso ajudar na gestão de fornadas, cardápio, estoque ou análise de vendas hoje?',
      time: 'Agora',
    },
  ]);
  const [inputText, setInputText] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);

  if (!isOpen) return null;

  // Key metrics for AI context
  const lowIngredients = ingredients.filter((i) => i.currentStock <= i.minStock);
  const activeBatchesCount = batches.filter((b) => b.status === 'assando' || b.status === 'fermentando').length;
  const completedSales = sales.filter((s) => s.status === 'concluida');
  const todayRevenue = completedSales.reduce((acc, s) => acc + s.total, 0);

  const quickPrompts = [
    '🥖 Como planejar as fornadas de pão francês para a tarde?',
    '📊 Analisar estoque crítico e sugerir lista de compras',
    '💰 Como aumentar o ticket médio do café da manhã?',
    '⚡ Sugestão de precificação para bolos confeitados',
  ];

  const handleSend = (textToSend?: string) => {
    const q = textToSend || inputText;
    if (!q.trim() || isGenerating) return;

    const userMsg = {
      role: 'user' as const,
      text: q,
      time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText('');
    setIsGenerating(true);

    setTimeout(() => {
      let reply = '';
      const lower = q.toLowerCase();

      if (lower.includes('fornada') || lower.includes('pão francês') || lower.includes('tarde')) {
        reply = `🥖 **Planejamento de Fornadas Recomendado:**\n\n• **Horário de Pico:** Entre 16h30 e 18h30 (60% da demanda de pão quente do turno da tarde).\n• **Volume Ideal:** Dividir a produção em 3 fornadas menores de 180 pães (às 16h00, 16h50 e 17h40) em vez de 1 grande fornada.\n• **Benefício:** Reduz sobras frias em 35% e atrai clientes pelo aroma de pão recém-saído no balcão.\n• **Fornos:** Manter temperatura a 220°C com injeção de vapor no primeiro minuto.`;
      } else if (lower.includes('estoque') || lower.includes('compras') || lower.includes('crítico')) {
        const items = lowIngredients.map((i) => `• **${i.name}:** Atual: ${i.currentStock} ${i.unit} (Mínimo: ${i.minStock} ${i.unit})`).join('\n');
        reply = `📊 **Diagnóstico de Estoque e Compras:**\n\n${items.length > 0 ? `Identifiquei ${lowIngredients.length} insumos abaixo do estoque de segurança:\n\n${items}\n\n**Ação:** Solicitar cotação urgente com o fornecedor Moinho Central para Farinha Especial e Laticínios da Serra para Manteiga.` : 'Todos os insumos essenciais estão dentro da margem de segurança operacional!'}`;
      } else if (lower.includes('ticket') || lower.includes('café') || lower.includes('vendas')) {
        reply = `💰 **Estratégia para Elevar Ticket Médio:**\n\n1. **Combos no PDV:** Ofereça "Café Coado + Pão na Chapa com Queijo" por R$ 9,90 (aumenta o valor por pedido em ~28%).\n2. **Exposição no Caixa:** Posicione broas embaladas, carolinas e pães de queijo na vitrine de impulso ao lado do operador de caixa.\n3. **Fidelidade:** Clientes que compram pão diariamente podem acumular pontos para café expresso grátis após 10 compras.`;
      } else {
        reply = `💡 **Recomendação Operacional:**\n\nCom base nos dados atuais da padaria (Faturamento do dia: **${formatCurrency(todayRevenue)}**, ${activeBatchesCount} fornadas ativas e status do caixa **${cashRegister.status}**), recomendo manter o ritmo de reposição de pães de queijo e monitorar a temperatura do forno 1 para a próxima saída de baguetes.`;
      }

      setMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          text: reply,
          time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
      setIsGenerating(false);
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl border border-stone-200 overflow-hidden flex flex-col max-h-[85vh] animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="px-6 py-4 bg-stone-900 text-white flex items-center justify-between border-b border-stone-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-amber-500 to-amber-700 flex items-center justify-center text-white shadow-md shadow-amber-950">
              <Sparkles className="w-5 h-5 text-amber-200 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base font-['Outfit']">Mestre Padeiro IA</h3>
                <span className="text-[10px] bg-amber-400/20 text-amber-300 font-bold px-2 py-0.5 rounded-full border border-amber-400/40">
                  Gemini Pro
                </span>
              </div>
              <p className="text-xs text-stone-400">Consultoria de Produção, Cardápio e Otimização da Padaria</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-stone-400 hover:text-white hover:bg-stone-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Suggestion Chips */}
        <div className="px-6 py-3 bg-stone-50 border-b border-stone-100 flex items-center gap-2 overflow-x-auto custom-scrollbar">
          <span className="text-[11px] font-bold text-stone-400 uppercase tracking-wider shrink-0 flex items-center gap-1">
            <Lightbulb className="w-3.5 h-3.5 text-amber-500" />
            Sugestões:
          </span>
          {quickPrompts.map((prompt, i) => (
            <button
              key={i}
              onClick={() => handleSend(prompt)}
              className="text-xs px-3 py-1.5 rounded-xl bg-white hover:bg-amber-50 border border-stone-200 hover:border-amber-300 text-stone-700 font-medium whitespace-nowrap transition-all shadow-2xs shrink-0"
            >
              {prompt}
            </button>
          ))}
        </div>

        {/* Chat History */}
        <div className="flex-1 p-6 overflow-y-auto space-y-4 custom-scrollbar bg-stone-50/50">
          {messages.map((m, idx) => (
            <div
              key={idx}
              className={`flex gap-3 ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {m.role === 'assistant' && (
                <div className="w-8 h-8 rounded-xl bg-amber-500 text-white flex items-center justify-center shrink-0 shadow-xs">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`max-w-[80%] rounded-2xl p-4 text-xs sm:text-sm leading-relaxed ${
                  m.role === 'user'
                    ? 'bg-amber-600 text-white shadow-xs'
                    : 'bg-white text-stone-800 border border-stone-200 shadow-2xs'
                }`}
              >
                <div className="whitespace-pre-line">{m.text}</div>
                <span
                  className={`block text-[10px] mt-2 font-mono ${
                    m.role === 'user' ? 'text-amber-200 text-right' : 'text-stone-400'
                  }`}
                >
                  {m.time}
                </span>
              </div>
            </div>
          ))}

          {isGenerating && (
            <div className="flex gap-3 items-center text-stone-500 text-xs">
              <div className="w-8 h-8 rounded-xl bg-amber-500 text-white flex items-center justify-center shrink-0 animate-pulse">
                <Bot className="w-4 h-4" />
              </div>
              <div className="bg-white border border-stone-200 p-3 rounded-2xl shadow-2xs flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-amber-500 animate-bounce" />
                <span className="w-2 h-2 rounded-full bg-amber-500 animate-bounce [animation-delay:0.2s]" />
                <span className="w-2 h-2 rounded-full bg-amber-500 animate-bounce [animation-delay:0.4s]" />
                <span className="text-stone-600 font-medium ml-1">Analisando dados da padaria...</span>
              </div>
            </div>
          )}
        </div>

        {/* Input Bar */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="p-4 bg-white border-t border-stone-200 flex items-center gap-3"
        >
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Pergunte sobre fornadas, insumos, rendimento, vendas ou receitas..."
            className="flex-1 px-4 py-3 rounded-xl bg-stone-50 border border-stone-200 text-stone-800 text-sm focus:outline-none focus:border-amber-500 focus:bg-white transition-all"
          />
          <button
            type="submit"
            disabled={!inputText.trim() || isGenerating}
            className="px-5 py-3 rounded-xl bg-amber-600 hover:bg-amber-700 disabled:opacity-50 text-white font-bold text-sm shadow-md transition-all flex items-center gap-2"
          >
            <span>Enviar</span>
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
