import React, { useState, useMemo } from 'react';
import { useBakery } from '../../context/BakeryContext';
import { 
  Plus, Search, Edit2, Trash2, LayoutGrid, List, 
  ShoppingBag, Tag, DollarSign, Percent, AlertTriangle, X, Check, Eye 
} from 'lucide-react';
import { formatCurrency, formatNumber, getCategoryLabel } from '../../lib/formatters';
import { Product, ProductCategory } from '../../types';

export const ProductsView: React.FC = () => {
  const { products, addProduct, updateProduct, deleteProduct } = useBakery();
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('table');
  const [selectedCategory, setSelectedCategory] = useState<string>('todos');
  const [searchQuery, setSearchQuery] = useState('');

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProductId, setEditingProductId] = useState<string | null>(null);

  // Form State
  const [formData, setFormData] = useState({
    name: '',
    code: '',
    category: 'paes' as ProductCategory,
    unit: 'un' as 'un' | 'kg' | 'cento' | 'fatia' | 'litro',
    price: 0,
    cost: 0,
    stock: 10,
    minStock: 5,
    image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=400',
    description: '',
    isBakeryProduced: true,
    active: true,
  });

  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      const matchesCat = selectedCategory === 'todos' || p.category === selectedCategory;
      const matchesSearch = 
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
        p.code.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCat && matchesSearch;
    });
  }, [products, selectedCategory, searchQuery]);

  // Statistics
  const totalProducts = products.length;
  const inHouseCount = products.filter((p) => p.isBakeryProduced).length;
  const avgMargin = products.reduce((acc, p) => {
    const margin = p.price > 0 ? ((p.price - p.cost) / p.price) * 100 : 0;
    return acc + margin;
  }, 0) / (totalProducts || 1);

  const handleOpenAdd = () => {
    const nextCode = String(100 + products.length + 1);
    setEditingProductId(null);
    setFormData({
      name: '',
      code: nextCode,
      category: 'paes',
      unit: 'un',
      price: 10.0,
      cost: 3.5,
      stock: 20,
      minStock: 5,
      image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=400',
      description: '',
      isBakeryProduced: true,
      active: true,
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (p: Product) => {
    setEditingProductId(p.id);
    setFormData({
      name: p.name,
      code: p.code,
      category: p.category,
      unit: p.unit,
      price: p.price,
      cost: p.cost,
      stock: p.stock,
      minStock: p.minStock,
      image: p.image,
      description: p.description || '',
      isBakeryProduced: p.isBakeryProduced,
      active: p.active,
    });
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingProductId) {
      updateProduct(editingProductId, formData);
    } else {
      addProduct(formData);
    }
    setIsModalOpen(false);
  };

  const calculatedMargin = formData.price > 0 
    ? (((formData.price - formData.cost) / formData.price) * 100).toFixed(1)
    : '0';

  return (
    <div id="products-view" className="space-y-6">
      {/* Top Header & Summary Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs">
          <span className="text-xs font-bold text-stone-500 uppercase tracking-wider">
            Total no Cardápio
          </span>
          <p className="text-2xl font-extrabold text-stone-900 font-['Outfit'] mt-1">
            {totalProducts} itens
          </p>
          <p className="text-xs text-amber-700 font-semibold mt-1">
            {inHouseCount} de fabricação própria
          </p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs">
          <span className="text-xs font-bold text-stone-500 uppercase tracking-wider">
            Margem de Lucro Média
          </span>
          <p className="text-2xl font-extrabold text-emerald-700 font-['Outfit'] mt-1">
            {avgMargin.toFixed(1)}%
          </p>
          <p className="text-xs text-stone-500 mt-1">
            Rentabilidade saudável em panificação
          </p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-stone-500 uppercase tracking-wider">
              Gerenciar Cardápio
            </span>
            <p className="text-xs text-stone-600 mt-1">Cadastre novos pães, doces e salgados</p>
          </div>
          <button
            id="btn-add-new-product"
            onClick={handleOpenAdd}
            className="px-4 py-2.5 bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center gap-1.5 shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Novo Produto</span>
          </button>
        </div>
      </div>

      {/* Filter and View Mode Controls */}
      <div className="bg-white p-4 rounded-3xl border border-stone-200 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="relative w-full sm:w-96">
            <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-3" />
            <input
              id="input-products-search"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Buscar por nome, código ou categoria..."
              className="w-full pl-10 pr-4 py-2 rounded-xl bg-stone-50 border border-stone-200 text-stone-900 text-sm focus:outline-none focus:border-amber-500 transition-colors"
            />
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            <div className="flex items-center bg-stone-100 p-1 rounded-xl border border-stone-200">
              <button
                id="btn-view-table"
                onClick={() => setViewMode('table')}
                className={`p-1.5 rounded-lg transition-colors ${viewMode === 'table' ? 'bg-white shadow-xs text-stone-900' : 'text-stone-500'}`}
                title="Visualização em Tabela"
              >
                <List className="w-4 h-4" />
              </button>
              <button
                id="btn-view-grid"
                onClick={() => setViewMode('grid')}
                className={`p-1.5 rounded-lg transition-colors ${viewMode === 'grid' ? 'bg-white shadow-xs text-stone-900' : 'text-stone-500'}`}
                title="Visualização em Grade"
              >
                <LayoutGrid className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex gap-2 overflow-x-auto pb-1 custom-scrollbar">
          {[
            { id: 'todos', label: 'Todos' },
            { id: 'paes', label: 'Pães & Broas' },
            { id: 'salgados', label: 'Salgados' },
            { id: 'confeitaria', label: 'Confeitaria' },
            { id: 'bebidas', label: 'Bebidas' },
            { id: 'frios', label: 'Frios & Queijos' },
            { id: 'mercearia', label: 'Mercearia' },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-1 rounded-full text-xs font-bold whitespace-nowrap transition-all ${
                selectedCategory === cat.id
                  ? 'bg-amber-500 text-white'
                  : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Table or Grid Content */}
      {viewMode === 'table' ? (
        <div className="bg-white rounded-3xl border border-stone-200 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-stone-700">
              <thead className="bg-stone-50 border-b border-stone-200 font-bold uppercase text-stone-500 tracking-wider">
                <tr>
                  <th className="py-3 px-4">Cód / PLU</th>
                  <th className="py-3 px-4">Produto</th>
                  <th className="py-3 px-4">Categoria</th>
                  <th className="py-3 px-4 text-right">Preço Venda</th>
                  <th className="py-3 px-4 text-right">Custo</th>
                  <th className="py-3 px-4 text-right">Margem</th>
                  <th className="py-3 px-4 text-center">Estoque Atual</th>
                  <th className="py-3 px-4 text-right">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {filteredProducts.map((p) => {
                  const marginPct = p.price > 0 ? ((p.price - p.cost) / p.price) * 100 : 0;
                  const isLow = p.stock <= p.minStock;

                  return (
                    <tr key={p.id} className="hover:bg-amber-50/30 transition-colors">
                      <td className="py-3 px-4 font-mono font-bold text-stone-900">
                        #{p.code}
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-3">
                          <img
                            src={p.image}
                            alt={p.name}
                            className="w-10 h-10 rounded-xl object-cover border border-stone-200 shrink-0"
                          />
                          <div>
                            <p className="font-bold text-stone-900 leading-snug">{p.name}</p>
                            {p.isBakeryProduced && (
                              <span className="text-[10px] text-amber-700 font-semibold">
                                Produção Própria
                              </span>
                            )}
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4 capitalize">{getCategoryLabel(p.category)}</td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-stone-900">
                        {formatCurrency(p.price)} <span className="text-stone-400 font-normal">/{p.unit}</span>
                      </td>
                      <td className="py-3 px-4 text-right font-mono text-stone-500">
                        {formatCurrency(p.cost)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-emerald-700">
                        {marginPct.toFixed(1)}%
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span
                          className={`px-2.5 py-1 rounded-full font-mono font-bold text-[11px] ${
                            isLow
                              ? 'bg-rose-100 text-rose-800 border border-rose-200'
                              : 'bg-stone-100 text-stone-800'
                          }`}
                        >
                          {formatNumber(p.stock, p.unit === 'kg' ? 2 : 0)} {p.unit}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            id={`btn-edit-product-${p.id}`}
                            onClick={() => handleOpenEdit(p)}
                            className="p-1.5 text-stone-500 hover:text-amber-700 hover:bg-amber-50 rounded-lg transition-colors"
                            title="Editar Produto"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            id={`btn-delete-product-${p.id}`}
                            onClick={() => {
                              if (confirm(`Deseja excluir "${p.name}"?`)) {
                                deleteProduct(p.id);
                              }
                            }}
                            className="p-1.5 text-stone-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                            title="Excluir"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filteredProducts.map((p) => {
            const marginPct = p.price > 0 ? ((p.price - p.cost) / p.price) * 100 : 0;

            return (
              <div
                key={p.id}
                className="bg-white rounded-3xl border border-stone-200 hover:border-amber-400 shadow-xs p-4 space-y-3 transition-all flex flex-col justify-between"
              >
                <div className="space-y-3">
                  <div className="w-full h-36 rounded-2xl overflow-hidden bg-stone-100 relative">
                    <img src={p.image} alt={p.name} className="w-full h-full object-cover" />
                    <span className="absolute top-2 left-2 px-2 py-0.5 rounded-lg bg-black/60 backdrop-blur-xs text-white font-mono text-xs font-bold">
                      #{p.code}
                    </span>
                    <span className="absolute top-2 right-2 px-2 py-0.5 rounded-lg bg-white/90 backdrop-blur-xs text-stone-800 text-[10px] font-bold capitalize">
                      {p.category}
                    </span>
                  </div>

                  <div>
                    <h4 className="font-bold text-sm text-stone-900 leading-snug">{p.name}</h4>
                    <p className="text-xs text-stone-400 mt-0.5 line-clamp-2">
                      {p.description || 'Sem descrição cadastrada.'}
                    </p>
                  </div>
                </div>

                <div className="pt-2 border-t border-stone-100 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <div>
                      <span className="text-stone-400">Preço: </span>
                      <strong className="text-stone-900 font-mono">{formatCurrency(p.price)}</strong>
                      <span className="text-stone-400 text-[10px]">/{p.unit}</span>
                    </div>
                    <span className="font-mono text-emerald-700 font-bold">
                      +{marginPct.toFixed(0)}%
                    </span>
                  </div>

                  <div className="flex items-center justify-between pt-1">
                    <span className="text-xs font-mono text-stone-600">
                      Estoque: <strong>{p.stock} {p.unit}</strong>
                    </span>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleOpenEdit(p)}
                        className="p-1.5 text-stone-500 hover:text-amber-700 hover:bg-stone-100 rounded-lg"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          if (confirm(`Excluir ${p.name}?`)) deleteProduct(p.id);
                        }}
                        className="p-1.5 text-stone-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add / Edit Product Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 space-y-5 shadow-2xl animate-in fade-in zoom-in-95 max-h-[90vh] overflow-y-auto custom-scrollbar">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <h3 className="font-bold text-base text-stone-900 font-['Outfit']">
                {editingProductId ? 'Editar Produto do Cardápio' : 'Cadastrar Novo Produto'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 rounded-lg text-stone-400 hover:text-stone-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Nome do Produto *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Ex: Pão de Batata Recheado"
                    className="w-full px-3 py-2 text-xs rounded-xl border border-stone-200 focus:border-amber-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Código PLU / Barra *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.code}
                    onChange={(e) => setFormData({ ...formData, code: e.target.value })}
                    placeholder="101"
                    className="w-full px-3 py-2 text-xs rounded-xl border border-stone-200 font-mono focus:border-amber-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Categoria
                  </label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value as ProductCategory })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-stone-200 focus:border-amber-500 focus:outline-none"
                  >
                    <option value="paes">Pães & Broas</option>
                    <option value="salgados">Salgados & Lanches</option>
                    <option value="confeitaria">Confeitaria & Bolos</option>
                    <option value="bebidas">Bebidas & Cafeteria</option>
                    <option value="frios">Frios & Laticínios</option>
                    <option value="mercearia">Mercearia</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Unidade de Venda
                  </label>
                  <select
                    value={formData.unit}
                    onChange={(e) => setFormData({ ...formData, unit: e.target.value as any })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-stone-200 focus:border-amber-500 focus:outline-none"
                  >
                    <option value="un">Unidade (un)</option>
                    <option value="kg">Quilo (kg / Pesável)</option>
                    <option value="fatia">Fatia</option>
                    <option value="cento">Cento</option>
                    <option value="litro">Litro</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Estoque Atual
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={formData.stock}
                    onChange={(e) => setFormData({ ...formData, stock: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-stone-200 font-mono focus:border-amber-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Price, Cost & Margin auto calculation */}
              <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-3">
                <div className="grid grid-cols-3 gap-3 items-center">
                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      Preço de Venda (R$) *
                    </label>
                    <input
                      type="number"
                      step="0.10"
                      required
                      value={formData.price}
                      onChange={(e) => setFormData({ ...formData, price: parseFloat(e.target.value) || 0 })}
                      className="w-full px-3 py-2 text-xs rounded-xl border border-amber-300 font-mono font-bold bg-white focus:border-amber-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      Custo Unitário (R$)
                    </label>
                    <input
                      type="number"
                      step="0.10"
                      value={formData.cost}
                      onChange={(e) => setFormData({ ...formData, cost: parseFloat(e.target.value) || 0 })}
                      className="w-full px-3 py-2 text-xs rounded-xl border border-stone-200 font-mono bg-white focus:border-amber-500 focus:outline-none"
                    />
                  </div>

                  <div className="text-center">
                    <span className="block text-[11px] font-bold text-stone-500 uppercase">
                      Margem Bruta
                    </span>
                    <span className="text-lg font-extrabold font-mono text-emerald-700">
                      {calculatedMargin}%
                    </span>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  URL da Foto do Produto
                </label>
                <input
                  type="url"
                  value={formData.image}
                  onChange={(e) => setFormData({ ...formData, image: e.target.value })}
                  placeholder="https://images.unsplash.com/..."
                  className="w-full px-3 py-2 text-xs rounded-xl border border-stone-200 focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Descrição & Ficha Rápida
                </label>
                <textarea
                  rows={2}
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Ingredientes principais, tempo de forno ou detalhes..."
                  className="w-full px-3 py-2 text-xs rounded-xl border border-stone-200 focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div className="flex items-center gap-4 text-xs">
                <label className="flex items-center gap-2 text-stone-700 font-semibold cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.isBakeryProduced}
                    onChange={(e) => setFormData({ ...formData, isBakeryProduced: e.target.checked })}
                    className="rounded text-amber-500 focus:ring-amber-500"
                  />
                  <span>Produzido na Padaria (In-house)</span>
                </label>

                <label className="flex items-center gap-2 text-stone-700 font-semibold cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.active}
                    onChange={(e) => setFormData({ ...formData, active: e.target.checked })}
                    className="rounded text-amber-500 focus:ring-amber-500"
                  />
                  <span>Item Ativo no Cardápio</span>
                </label>
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="flex-1 py-2.5 rounded-xl border border-stone-300 text-stone-700 font-bold text-xs hover:bg-stone-100"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs shadow-md"
                >
                  Salvar Produto
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
