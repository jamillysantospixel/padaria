import React, { useState } from 'react';
import { useBakery } from '../../context/BakeryContext';
import { Store, ShieldCheck, Flame, ShoppingBag, ArrowRight, Lock, Mail } from 'lucide-react';
import { User } from '../../types';

export const LoginScreen: React.FC = () => {
  const { users, loginAs } = useBakery();
  const [email, setEmail] = useState('carlos@sistemapadaria.com.br');
  const [password, setPassword] = useState('123456');

  const handleCustomLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const found = users.find((u) => u.email.toLowerCase() === email.toLowerCase());
    if (found) {
      loginAs(found);
    } else {
      // Fallback create custom admin
      const customUser: User = {
        id: 'user-custom',
        name: email.split('@')[0],
        email,
        role: 'admin',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
        shift: 'Geral',
      };
      loginAs(customUser);
    }
  };

  return (
    <div id="login-page" className="min-h-screen bg-stone-950 flex flex-col justify-center items-center p-4 sm:p-6 relative overflow-hidden">
      {/* Background bakery glow styling */}
      <div className="absolute top-1/4 -left-20 w-96 h-96 bg-amber-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 -right-20 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="w-full max-w-4xl grid grid-cols-1 lg:grid-cols-12 gap-8 items-center z-10">
        {/* Left Side: Brand Story & Quick Roles */}
        <div className="lg:col-span-6 text-stone-100 space-y-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-500 to-amber-700 flex items-center justify-center text-white shadow-xl shadow-amber-950">
              <Store className="w-7 h-7" />
            </div>
            <div>
              <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight font-['Outfit'] text-white">
                Sistema Padaria
              </h1>
              <p className="text-xs text-amber-400 font-semibold tracking-wide uppercase">
                Gestão Completa de Panificação & PDV
              </p>
            </div>
          </div>

          <p className="text-sm text-stone-400 leading-relaxed">
            Controle de ponta a ponta: Frente de Caixa ágil com pesagem por kg, controle de fornadas ao vivo, fichas técnicas de insumos, caderneta de fiado e demonstrativo financeiro DRE.
          </p>

          {/* Quick Demo Access Badges */}
          <div className="space-y-3 pt-2">
            <p className="text-xs font-bold uppercase tracking-wider text-amber-400/90 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4" />
              Acesso Rápido de Demonstração (1 Clique):
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {users.map((user) => (
                <button
                  key={user.id}
                  id={`btn-quick-login-${user.id}`}
                  onClick={() => loginAs(user)}
                  className="flex items-center gap-3 p-3 rounded-xl bg-stone-900/90 hover:bg-stone-800 border border-stone-800 hover:border-amber-500/50 text-left transition-all group"
                >
                  <img
                    src={user.avatar}
                    alt={user.name}
                    className="w-10 h-10 rounded-lg object-cover border border-amber-500/40 shrink-0 group-hover:scale-105 transition-transform"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold text-stone-200 group-hover:text-white truncate">
                      {user.name}
                    </p>
                    <p className="text-[11px] text-amber-400 capitalize font-medium">
                      {user.role === 'admin' ? 'Administrador' : user.role === 'padeiro' ? 'Padeiro Chefe' : user.role === 'caixa' ? 'Operador de Caixa' : 'Gerente'}
                    </p>
                  </div>
                  <ArrowRight className="w-4 h-4 text-stone-500 group-hover:text-amber-400 transition-colors shrink-0" />
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Side: Login Form Card */}
        <div className="lg:col-span-6">
          <div className="bg-stone-900 border border-stone-800 rounded-3xl p-6 sm:p-8 shadow-2xl backdrop-blur-xl">
            <div className="mb-6">
              <h2 className="text-xl font-bold text-white font-['Outfit']">Entrar no Sistema</h2>
              <p className="text-xs text-stone-400 mt-1">
                Digite suas credenciais ou selecione um perfil ao lado
              </p>
            </div>

            <form onSubmit={handleCustomLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-stone-300 mb-1.5">
                  E-mail de Acesso
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-stone-500 absolute left-3.5 top-3" />
                  <input
                    id="input-login-email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    placeholder="seu.email@sistemapadaria.com.br"
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-stone-950 border border-stone-800 text-stone-100 text-sm focus:outline-none focus:border-amber-500 transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-300 mb-1.5">
                  Senha
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-stone-500 absolute left-3.5 top-3" />
                  <input
                    id="input-login-password"
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    placeholder="••••••••"
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-stone-950 border border-stone-800 text-stone-100 text-sm focus:outline-none focus:border-amber-500 transition-colors"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between text-xs pt-1">
                <label className="flex items-center gap-2 text-stone-400 cursor-pointer">
                  <input type="checkbox" defaultChecked className="rounded text-amber-500 focus:ring-amber-500 bg-stone-950 border-stone-800" />
                  <span>Lembrar meu acesso</span>
                </label>
                <a href="#" onClick={(e) => { e.preventDefault(); alert('Utilize os botões de 1 clique à esquerda para testar qualquer função!'); }} className="text-amber-400 hover:underline">
                  Esqueceu a senha?
                </a>
              </div>

              <button
                id="btn-submit-login"
                type="submit"
                className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white font-bold text-sm tracking-wide shadow-lg shadow-amber-950 transition-all flex items-center justify-center gap-2 mt-4"
              >
                <span>Acessar Painel</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>

            <div className="mt-6 pt-4 border-t border-stone-800/80 text-center">
              <span className="text-[11px] text-stone-500">
                Padaria Modelo • Versão 2.4 Pro • Sistema em Português (Brasil)
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
