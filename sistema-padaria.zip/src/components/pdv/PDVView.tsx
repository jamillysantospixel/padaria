import React, { useState, useMemo } from 'react';
import { useBakery } from '../../context/BakeryContext';
import { 
  Search, ShoppingCart, Trash2, Plus, Minus, CreditCard, 
  Banknote, QrCode, BookOpen, Check, Printer, Scale, 
  User, Tag, ArrowRight, X, AlertCircle, RefreshCw, Flame
} from 'lucide-react';
import { formatCurrency, formatNumber, getCategoryLabel } from '../../lib/formatters';
import { Product, ProductCategory, PaymentMethod, Sale } from '../../types';

export const PDVView: React.FC = () => {
  const { 
    products, cart, addToCart, updateCartItemQuantity, 
    removeFromCart, clearCart, checkoutSale, customers, cashRegister 
  } = useBakery();

  const [selectedCategory, setSelectedCategory] = useState<string>('todos');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Weight modal for kg products
  const [weighProduct, setWeighProduct] = useState<Product | null>(null);
  const [weighedGrams, setWeighedGrams] = useState<number>(350); // Default 350g

  // Checkout modal
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('dinheiro');
  const [discountAmount, setDiscountAmount] = useState<number>(0);
  const [cashGiven, setCashGiven] = useState<number>(0);
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('');
  const [comandaNumber, setComandaNumber] = useState<string>('');
  const [completedSale, setCompletedSale] = useState<Sale | null>(null);

  // Filter products
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      if (!p.active) return false;
      const matchesCat = selectedCategory === 'todos' || p.category === selectedCategory;
      const matchesSearch = 
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
        p.code.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCat && matchesSearch;
    });
  }, [products, selectedCategory, searchQuery]);

  // Cart totals
  const subtotal = cart.reduce((acc, item) => acc + item.totalPrice, 0);
  const total = Math.max(0, subtotal - discountAmount);
  const change = paymentMethod === 'dinheiro' && cashGiven > total ? cashGiven - total : 0;

  const handleProductClick = (product: Product) => {
    if (product.unit === 'kg') {
      setWeighProduct(product);
      setWeighedGrams(350); // initial default 350g
    } else {
      addToCart(product, 1);
    }
  };

  const handleConfirmWeight = () => {
    if (weighProduct) {
      const kg = weighedGrams / 1000;
      addToCart(weighProduct, Number(kg.toFixed(3)));
      setWeighProduct(null);
    }
  };

  const handleFinishSale = () => {
    const sale = checkoutSale(
      paymentMethod,
      discountAmount,
      paymentMethod === 'dinheiro' ? (cashGiven || total) : total,
      selectedCustomerId || undefined,
      comandaNumber ? parseInt(comandaNumber, 10) : undefined
    );

    if (sale) {
      setCompletedSale(sale);
    }
  };

  const handleResetCheckout = () => {
    setIsCheckoutOpen(false);
    setCompletedSale(null);
    setDiscountAmount(0);
    setCashGiven(0);
    setSelectedCustomerId('');
    setComandaNumber('');
  };

  const categories: { id: string; label: string }[] = [
    { id: 'todos', label: 'Todos os Itens' },
    { id: 'paes', label: 'Pães & Broas' },
    { id: 'salgados', label: 'Salgados' },
    { id: 'confeitaria', label: 'Confeitaria & Bolos' },
    { id: 'bebidas', label: 'Cafeteria & Bebidas' },
    { id: 'frios', label: 'Frios & Queijos' },
    { id: 'mercearia', label: 'Mercearia' },
  ];

  return (
    <div id="pdv-view" className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-[calc(100vh-120px)] min-h-[650px]">
      {/* Left Column (7 cols on lg, 8 on xl): Product Catalog Grid */}
      <div className="lg:col-span-7 xl:col-span-8 flex flex-col gap-4 overflow-hidden">
        {/* Search & Category Header */}
        <div className="bg-white p-4 rounded-3xl border border-stone-200 shadow-xs space-y-3">
          <div className="flex items-center gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-3" />
              <input
                id="input-pdv-search"
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Buscar por nome ou código PLU (ex: 101 para Pão Francês)..."
                className="w-full pl-10 pr-4 py-2 rounded-xl bg-stone-50 border border-stone-200 text-stone-900 text-sm focus:outline-none focus:border-amber-500 transition-colors"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-2.5 text-stone-400 hover:text-stone-600"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Scale indicator */}
            <div className="hidden sm:flex items-center gap-1.5 px-3 py-2 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs font-semibold shrink-0">
              <Scale className="w-4 h-4 text-amber-600" />
              <span>Balança Conectada</span>
            </div>
          </div>

          {/* Category Pills */}
          <div className="flex gap-2 overflow-x-auto pb-1 custom-scrollbar">
            {categories.map((cat) => {
              const isSelected = selectedCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  id={`cat-filter-${cat.id}`}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-3.5 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all ${
                    isSelected
                      ? 'bg-amber-500 text-white shadow-xs'
                      : 'bg-stone-100 text-stone-600 hover:bg-stone-200 hover:text-stone-900'
                  }`}
                >
                  {cat.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Product Cards Grid */}
        <div className="flex-1 overflow-y-auto pr-1 space-y-2 custom-scrollbar">
          <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-3">
            {filteredProducts.map((product) => {
              const isLowStock = product.stock <= product.minStock;

              return (
                <button
                  key={product.id}
                  id={`btn-add-product-${product.code}`}
                  onClick={() => handleProductClick(product)}
                  className="p-3 bg-white hover:bg-amber-50/50 rounded-2xl border border-stone-200 hover:border-amber-400 shadow-xs text-left transition-all group flex flex-col justify-between relative overflow-hidden"
                >
                  {product.unit === 'kg' && (
                    <span className="absolute top-2 right-2 px-1.5 py-0.5 rounded bg-amber-100 border border-amber-300 text-amber-800 text-[10px] font-bold flex items-center gap-0.5">
                      <Scale className="w-3 h-3" />
                      <span>kg</span>
                    </span>
                  )}

                  <div className="space-y-2">
                    <div className="w-full h-24 rounded-xl overflow-hidden bg-stone-100 relative">
                      <img
                        src={product.image}
                        alt={product.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <span className="absolute bottom-1 left-1 bg-black/60 backdrop-blur-xs text-white text-[10px] font-mono px-1.5 py-0.5 rounded font-bold">
                        #{product.code}
                      </span>
                    </div>

                    <div>
                      <h4 className="text-xs font-bold text-stone-900 line-clamp-2 leading-snug">
                        {product.name}
                      </h4>
                      <p className="text-[10px] text-stone-400 capitalize">
                        {getCategoryLabel(product.category)}
                      </p>
                    </div>
                  </div>

                  <div className="mt-3 pt-2 border-t border-stone-100 flex items-center justify-between">
                    <div>
                      <span className="text-xs font-mono font-extrabold text-amber-700">
                        {formatCurrency(product.price)}
                      </span>
                      <span className="text-[10px] text-stone-400 ml-0.5">/{product.unit}</span>
                    </div>

                    <span className="w-6 h-6 rounded-lg bg-amber-500 text-white flex items-center justify-center text-xs font-bold group-hover:scale-110 transition-transform">
                      +
                    </span>
                  </div>
                </button>
              );
            })}
          </div>

          {filteredProducts.length === 0 && (
            <div className="p-12 text-center bg-white rounded-3xl border border-stone-200">
              <Search className="w-8 h-8 text-stone-300 mx-auto mb-2" />
              <p className="text-sm font-semibold text-stone-700">Nenhum produto encontrado</p>
              <p className="text-xs text-stone-400 mt-1">Tente buscar por outro nome ou código.</p>
            </div>
          )}
        </div>
      </div>

      {/* Right Column (5 cols on lg, 4 on xl): Active Cart & Checkout */}
      <div className="lg:col-span-5 xl:col-span-4 bg-white rounded-3xl border border-stone-200 shadow-sm flex flex-col overflow-hidden">
        {/* Cart Header */}
        <div className="p-4 border-b border-stone-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShoppingCart className="w-5 h-5 text-amber-600" />
            <h3 className="font-bold text-base text-stone-900 font-['Outfit']">
              Carrinho da Venda
            </h3>
            <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-800">
              {cart.length}
            </span>
          </div>

          {cart.length > 0 && (
            <button
              id="btn-clear-cart"
              onClick={clearCart}
              className="text-xs text-rose-500 hover:text-rose-700 font-semibold flex items-center gap-1 hover:underline"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Limpar</span>
            </button>
          )}
        </div>

        {/* Optional Comanda & Customer Quick Selector */}
        <div className="px-4 py-2.5 bg-stone-50 border-b border-stone-200 flex items-center gap-2">
          <div className="flex-1 relative">
            <input
              id="input-comanda-number"
              type="number"
              value={comandaNumber}
              onChange={(e) => setComandaNumber(e.target.value)}
              placeholder="Nº Comanda / Mesa..."
              className="w-full pl-3 pr-2 py-1.5 text-xs rounded-xl bg-white border border-stone-200 focus:outline-none focus:border-amber-500"
            />
          </div>

          <div className="flex-1 relative">
            <select
              id="select-cart-customer"
              value={selectedCustomerId}
              onChange={(e) => setSelectedCustomerId(e.target.value)}
              className="w-full px-3 py-1.5 text-xs rounded-xl bg-white border border-stone-200 focus:outline-none focus:border-amber-500 text-stone-700"
            >
              <option value="">Cliente Avulso (Balcão)</option>
              {customers.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} {c.creditBalance > 0 ? `(Fiado: R$ ${c.creditBalance.toFixed(2)})` : ''}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Cart Item List */}
        <div className="flex-1 p-4 overflow-y-auto space-y-2.5 custom-scrollbar">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 text-stone-400">
              <ShoppingCart className="w-12 h-12 text-stone-200 mb-3" />
              <p className="font-semibold text-sm text-stone-600">O carrinho está vazio</p>
              <p className="text-xs text-stone-400 mt-1 max-w-[200px]">
                Toque nos produtos ao lado ou busque pelo código para adicionar à venda.
              </p>
            </div>
          ) : (
            cart.map((item) => (
              <div
                key={item.product.id}
                className="p-2.5 rounded-2xl bg-stone-50 hover:bg-amber-50/40 border border-stone-200 transition-colors flex items-center justify-between gap-3"
              >
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-bold text-stone-900 truncate">
                    {item.product.name}
                  </p>
                  <p className="text-[11px] text-stone-500">
                    {formatNumber(item.quantity, item.product.unit === 'kg' ? 3 : 0)} {item.product.unit} × {formatCurrency(item.unitPrice)}
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <span className="text-xs font-mono font-bold text-stone-900">
                    {formatCurrency(item.totalPrice)}
                  </span>

                  {/* Quantity Stepper */}
                  <div className="flex items-center gap-1 bg-white border border-stone-200 rounded-xl p-0.5">
                    <button
                      id={`btn-cart-minus-${item.product.id}`}
                      onClick={() =>
                        updateCartItemQuantity(
                          item.product.id,
                          item.product.unit === 'kg' ? item.quantity - 0.1 : item.quantity - 1
                        )
                      }
                      className="p-1 text-stone-600 hover:bg-stone-100 rounded-lg"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="text-xs font-bold px-1 font-mono min-w-[24px] text-center">
                      {item.product.unit === 'kg' ? item.quantity.toFixed(2) : item.quantity}
                    </span>
                    <button
                      id={`btn-cart-plus-${item.product.id}`}
                      onClick={() =>
                        updateCartItemQuantity(
                          item.product.id,
                          item.product.unit === 'kg' ? item.quantity + 0.1 : item.quantity + 1
                        )
                      }
                      className="p-1 text-stone-600 hover:bg-stone-100 rounded-lg"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>

                  <button
                    id={`btn-cart-remove-${item.product.id}`}
                    onClick={() => removeFromCart(item.product.id)}
                    className="p-1.5 text-stone-400 hover:text-rose-500 rounded-lg transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Cart Financial Summary & Checkout Button */}
        <div className="p-4 bg-stone-50/80 border-t border-stone-200 space-y-3">
          <div className="space-y-1.5 text-xs">
            <div className="flex items-center justify-between text-stone-600">
              <span>Subtotal dos itens:</span>
              <span className="font-mono font-semibold">{formatCurrency(subtotal)}</span>
            </div>
            {discountAmount > 0 && (
              <div className="flex items-center justify-between text-emerald-700">
                <span>Desconto aplicado:</span>
                <span className="font-mono font-semibold">- {formatCurrency(discountAmount)}</span>
              </div>
            )}
            <div className="flex items-center justify-between text-base font-extrabold text-stone-900 pt-1 border-t border-stone-200 font-['Outfit']">
              <span>Total a Pagar:</span>
              <span className="text-xl font-mono text-amber-800">{formatCurrency(total)}</span>
            </div>
          </div>

          <button
            id="btn-open-checkout-modal"
            disabled={cart.length === 0}
            onClick={() => setIsCheckoutOpen(true)}
            className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 disabled:opacity-50 text-white font-bold text-sm tracking-wide shadow-md shadow-amber-950/20 transition-all flex items-center justify-center gap-2"
          >
            <span>Receber Pagamento</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Scale / Weight Modal for kg items */}
      {weighProduct && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 space-y-5 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Scale className="w-5 h-5 text-amber-600" />
                <h3 className="font-bold text-stone-900 font-['Outfit'] text-base">
                  Pesar Produto ({weighProduct.name})
                </h3>
              </div>
              <button
                onClick={() => setWeighProduct(null)}
                className="p-1 rounded-lg text-stone-400 hover:text-stone-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 bg-amber-50 rounded-2xl border border-amber-200 text-center space-y-1">
              <p className="text-xs font-semibold text-amber-900 uppercase tracking-wider">
                Preço: {formatCurrency(weighProduct.price)} / kg
              </p>
              <p className="text-3xl font-extrabold font-mono text-amber-900">
                {(weighedGrams / 1000).toFixed(3)} kg ({weighedGrams}g)
              </p>
              <p className="text-sm font-bold text-amber-700">
                Total: {formatCurrency((weighedGrams / 1000) * weighProduct.price)}
              </p>
            </div>

            {/* Quick Grams Buttons */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-stone-600">
                Pesos Rápidos / Padrão:
              </label>
              <div className="grid grid-cols-4 gap-2">
                {[150, 250, 350, 500, 750, 1000, 1500, 2000].map((g) => (
                  <button
                    key={g}
                    id={`btn-weigh-preset-${g}`}
                    onClick={() => setWeighedGrams(g)}
                    className={`py-2 rounded-xl text-xs font-bold border transition-colors ${
                      weighedGrams === g
                        ? 'bg-amber-500 text-white border-amber-600'
                        : 'bg-stone-100 hover:bg-stone-200 text-stone-700 border-stone-200'
                    }`}
                  >
                    {g >= 1000 ? `${g / 1000} kg` : `${g}g`}
                  </button>
                ))}
              </div>
            </div>

            {/* Manual Grams Input */}
            <div>
              <label className="block text-xs font-semibold text-stone-600 mb-1">
                Ou digite a gramatura exata (g):
              </label>
              <input
                id="input-manual-grams"
                type="number"
                value={weighedGrams}
                onChange={(e) => setWeighedGrams(Math.max(1, parseInt(e.target.value, 10) || 0))}
                className="w-full px-4 py-2.5 rounded-xl border border-stone-300 font-mono text-base font-bold focus:outline-none focus:border-amber-500"
              />
            </div>

            <div className="flex gap-3 pt-2">
              <button
                onClick={() => setWeighProduct(null)}
                className="flex-1 py-2.5 rounded-xl border border-stone-300 text-stone-700 font-bold text-xs hover:bg-stone-100"
              >
                Cancelar
              </button>
              <button
                id="btn-confirm-weight"
                onClick={handleConfirmWeight}
                className="flex-1 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs shadow-md"
              >
                Adicionar ao Carrinho
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Checkout / Payment Modal */}
      {isCheckoutOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 space-y-6 shadow-2xl animate-in fade-in zoom-in-95 max-h-[90vh] overflow-y-auto custom-scrollbar">
            {!completedSale ? (
              <>
                <div className="flex items-center justify-between border-b border-stone-100 pb-3">
                  <div>
                    <h3 className="font-extrabold text-lg text-stone-900 font-['Outfit']">
                      Finalizar Venda & Pagamento
                    </h3>
                    <p className="text-xs text-stone-500">Escolha a forma de pagamento do cliente</p>
                  </div>
                  <button
                    onClick={() => setIsCheckoutOpen(false)}
                    className="p-1 rounded-lg text-stone-400 hover:text-stone-700"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Total Display */}
                <div className="p-4 bg-stone-900 text-white rounded-2xl flex items-center justify-between">
                  <div>
                    <span className="text-xs text-amber-400 font-bold uppercase tracking-wider">
                      Valor Total da Venda
                    </span>
                    <p className="text-2xl font-mono font-extrabold text-white">
                      {formatCurrency(total)}
                    </p>
                  </div>
                  <span className="text-xs px-3 py-1 rounded-full bg-stone-800 text-stone-300 font-mono">
                    {cart.length} itens
                  </span>
                </div>

                {/* Payment Methods Grid */}
                <div className="space-y-2">
                  <label className="text-xs font-bold text-stone-700 uppercase tracking-wider">
                    Forma de Pagamento:
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {[
                      { id: 'dinheiro', label: 'Dinheiro', icon: Banknote },
                      { id: 'pix', label: 'PIX Instantâneo', icon: QrCode },
                      { id: 'debito', label: 'Cartão Débito', icon: CreditCard },
                      { id: 'credito', label: 'Cartão Crédito', icon: CreditCard },
                      { id: 'fiado', label: 'Caderneta / Fiado', icon: BookOpen },
                    ].map((pm) => {
                      const Icon = pm.icon;
                      const isSelected = paymentMethod === pm.id;
                      return (
                        <button
                          key={pm.id}
                          id={`pay-method-${pm.id}`}
                          onClick={() => setPaymentMethod(pm.id as PaymentMethod)}
                          className={`p-3 rounded-2xl border text-left flex flex-col justify-between gap-2 transition-all ${
                            isSelected
                              ? 'bg-amber-500 text-white border-amber-600 shadow-xs'
                              : 'bg-stone-50 hover:bg-stone-100 text-stone-700 border-stone-200'
                          }`}
                        >
                          <Icon className={`w-5 h-5 ${isSelected ? 'text-white' : 'text-amber-600'}`} />
                          <span className="text-xs font-bold leading-tight">{pm.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Dinheiro Calculator / Cash Given & Change */}
                {paymentMethod === 'dinheiro' && (
                  <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200 space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-bold text-amber-900">
                        Valor Entregue pelo Cliente:
                      </label>
                      {change > 0 && (
                        <span className="text-xs font-mono font-extrabold text-emerald-700">
                          Troco: {formatCurrency(change)}
                        </span>
                      )}
                    </div>

                    <input
                      id="input-cash-given"
                      type="number"
                      step="0.50"
                      value={cashGiven || ''}
                      onChange={(e) => setCashGiven(parseFloat(e.target.value) || 0)}
                      placeholder={`Ex: R$ ${total.toFixed(2)}`}
                      className="w-full px-4 py-2 rounded-xl bg-white border border-amber-300 font-mono text-base font-bold focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />

                    {/* Quick Cash Bills */}
                    <div className="flex gap-2 flex-wrap">
                      {[10, 20, 50, 100].map((bill) => (
                        <button
                          key={bill}
                          id={`btn-cash-bill-${bill}`}
                          onClick={() => setCashGiven(bill)}
                          className="px-3 py-1 rounded-lg bg-white hover:bg-amber-100 border border-amber-200 text-xs font-mono font-bold text-amber-900 shadow-xs"
                        >
                          R$ {bill}
                        </button>
                      ))}
                      <button
                        id="btn-cash-exact"
                        onClick={() => setCashGiven(total)}
                        className="px-3 py-1 rounded-lg bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold shadow-xs"
                      >
                        Valor Exato
                      </button>
                    </div>
                  </div>
                )}

                {/* PIX Display */}
                {paymentMethod === 'pix' && (
                  <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 text-center space-y-3">
                    <div className="w-36 h-36 mx-auto bg-white p-2 rounded-xl border border-stone-300 flex items-center justify-center shadow-xs">
                      {/* Stylized QR Code placeholder */}
                      <div className="grid grid-cols-4 gap-1 w-full h-full p-2 bg-stone-900 rounded-lg">
                        {Array.from({ length: 16 }).map((_, i) => (
                          <div
                            key={i}
                            className={`rounded-xs ${i % 2 === 0 || i % 5 === 0 ? 'bg-amber-400' : 'bg-white'}`}
                          />
                        ))}
                      </div>
                    </div>
                    <div>
                      <p className="text-xs font-bold text-stone-800">Chave PIX: CNPJ Padaria</p>
                      <p className="text-[11px] text-stone-500 font-mono">12.345.678/0001-90</p>
                    </div>
                  </div>
                )}

                {/* Fiado Notice */}
                {paymentMethod === 'fiado' && (
                  <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 space-y-2">
                    <div className="flex items-center gap-2 text-amber-900 text-xs font-bold">
                      <BookOpen className="w-4 h-4 text-amber-700" />
                      <span>Venda na Caderneta Digital (Fiado)</span>
                    </div>
                    <p className="text-xs text-amber-800">
                      O valor de <strong>{formatCurrency(total)}</strong> será adicionado ao saldo devedor do cliente cadastrado.
                    </p>
                    {!selectedCustomerId && (
                      <p className="text-xs text-rose-600 font-semibold">
                        ⚠️ Atenção: Selecione um cliente no topo do carrinho para vincular a conta de fiado.
                      </p>
                    )}
                  </div>
                )}

                {/* Discount Input */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Desconto na Venda (R$):
                  </label>
                  <input
                    id="input-discount-amount"
                    type="number"
                    step="0.10"
                    value={discountAmount || ''}
                    onChange={(e) => setDiscountAmount(parseFloat(e.target.value) || 0)}
                    placeholder="0,00"
                    className="w-full px-3 py-2 rounded-xl bg-stone-50 border border-stone-200 text-xs font-mono focus:outline-none focus:border-amber-500"
                  />
                </div>

                {/* Action Buttons */}
                <div className="flex gap-3 pt-2">
                  <button
                    onClick={() => setIsCheckoutOpen(false)}
                    className="flex-1 py-3 rounded-xl border border-stone-300 text-stone-700 font-bold text-xs hover:bg-stone-100 transition-colors"
                  >
                    Voltar
                  </button>
                  <button
                    id="btn-confirm-checkout"
                    onClick={handleFinishSale}
                    disabled={paymentMethod === 'fiado' && !selectedCustomerId}
                    className="flex-1 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold text-xs shadow-md transition-all flex items-center justify-center gap-2"
                  >
                    <Check className="w-4 h-4" />
                    <span>Concluir Venda</span>
                  </button>
                </div>
              </>
            ) : (
              /* Receipt / Comprovante view */
              <div className="space-y-4">
                <div className="text-center space-y-1">
                  <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 mx-auto flex items-center justify-center mb-2">
                    <Check className="w-6 h-6" />
                  </div>
                  <h3 className="font-extrabold text-lg text-stone-900 font-['Outfit']">
                    Venda Concluída com Sucesso!
                  </h3>
                  <p className="text-xs text-stone-500">
                    Cupom de Venda #{completedSale.saleNumber}
                  </p>
                </div>

                {/* Printed receipt style card */}
                <div className="p-4 bg-stone-50 rounded-2xl border border-dashed border-stone-300 font-mono text-xs text-stone-800 space-y-3">
                  <div className="text-center border-b border-stone-300 pb-2">
                    <p className="font-bold text-sm">PADARIA & CONFEITARIA MODELO</p>
                    <p className="text-[10px] text-stone-500">CNPJ: 12.345.678/0001-90</p>
                    <p className="text-[10px] text-stone-500">{completedSale.date}</p>
                  </div>

                  <div className="space-y-1 border-b border-stone-300 pb-2">
                    {completedSale.items.map((item, idx) => (
                      <div key={idx} className="flex justify-between text-[11px]">
                        <span>
                          {formatNumber(item.quantity, item.product.unit === 'kg' ? 3 : 0)} {item.product.unit} × {item.product.name}
                        </span>
                        <span>{formatCurrency(item.totalPrice)}</span>
                      </div>
                    ))}
                  </div>

                  <div className="space-y-1 border-b border-stone-300 pb-2 text-xs">
                    <div className="flex justify-between">
                      <span>Subtotal:</span>
                      <span>{formatCurrency(completedSale.subtotal)}</span>
                    </div>
                    {completedSale.discount > 0 && (
                      <div className="flex justify-between text-emerald-700">
                        <span>Desconto:</span>
                        <span>-{formatCurrency(completedSale.discount)}</span>
                      </div>
                    )}
                    <div className="flex justify-between font-bold text-sm">
                      <span>TOTAL:</span>
                      <span>{formatCurrency(completedSale.total)}</span>
                    </div>
                    <div className="flex justify-between text-[11px] text-stone-600">
                      <span>Pagamento:</span>
                      <span className="uppercase">{completedSale.paymentMethod}</span>
                    </div>
                    {completedSale.change && completedSale.change > 0 ? (
                      <div className="flex justify-between text-[11px] text-stone-600">
                        <span>Troco:</span>
                        <span>{formatCurrency(completedSale.change)}</span>
                      </div>
                    ) : null}
                  </div>

                  <div className="text-center text-[10px] text-stone-500 pt-1">
                    <p>Obrigado pela preferência!</p>
                    <p>Volte Sempre 🍞✨</p>
                  </div>
                </div>

                <div className="flex gap-3 pt-2">
                  <button
                    id="btn-print-receipt"
                    onClick={() => window.print()}
                    className="flex-1 py-2.5 rounded-xl border border-stone-300 hover:bg-stone-100 text-stone-700 font-bold text-xs flex items-center justify-center gap-2"
                  >
                    <Printer className="w-4 h-4" />
                    <span>Imprimir Cupom</span>
                  </button>
                  <button
                    id="btn-new-sale-after-finish"
                    onClick={handleResetCheckout}
                    className="flex-1 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs shadow-md"
                  >
                    Próxima Venda
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
