import React from 'react';
import { useBakery } from '../../context/BakeryContext';
import { NavigationTab } from '../layout/Sidebar';
import { 
  DollarSign, ShoppingBag, Users, Flame, AlertTriangle, 
  ArrowUpRight, Clock, Plus, ChevronRight, Sparkles, TrendingUp, CheckCircle2 
} from 'lucide-react';
import { formatCurrency, formatNumber } from '../../lib/formatters';

interface DashboardViewProps {
  setActiveTab: (tab: NavigationTab) => void;
  openAiModal: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ setActiveTab, openAiModal }) => {
  const { sales, products, ingredients, batches, cashRegister, customers, advanceBatchStatus } = useBakery();

  // Calculate today's completed sales
  const completedSales = sales.filter((s) => s.status === 'concluida');
  const todayTotalRevenue = completedSales.reduce((acc, s) => acc + s.total, 0);
  const totalOrders = completedSales.length;
  const averageTicket = totalOrders > 0 ? todayTotalRevenue / totalOrders : 0;

  // Bread French stock & production
  const frenchBread = products.find((p) => p.code === '101');
  const activeBatches = batches.filter((b) => b.status !== 'esgotado');

  // Low stock alerts
  const criticalProducts = products.filter((p) => p.stock <= p.minStock);
  const criticalIngredients = ingredients.filter((i) => i.currentStock <= i.minStock);
  const totalAlerts = criticalProducts.length + criticalIngredients.length;

  // Top selling products by frequency in sales
  const productSalesMap: Record<string, { product: typeof products[0]; quantity: number; total: number }> = {};
  completedSales.forEach((sale) => {
    sale.items.forEach((item) => {
      const pid = item.product.id;
      if (!productSalesMap[pid]) {
        productSalesMap[pid] = { product: item.product, quantity: 0, total: 0 };
      }
      productSalesMap[pid].quantity += item.quantity;
      productSalesMap[pid].total += item.totalPrice;
    });
  });

  const topSellers = Object.values(productSalesMap)
    .sort((a, b) => b.total - a.total)
    .slice(0, 5);

  // Hourly distribution data
  const hourlyData = [
    { period: '06h - 09h', label: 'Café da Manhã', amount: todayTotalRevenue * 0.45, pct: 45 },
    { period: '09h - 12h', label: 'Meio do Dia', amount: todayTotalRevenue * 0.15, pct: 15 },
    { period: '12h - 15h', label: 'Almoço & Lanche', amount: todayTotalRevenue * 0.12, pct: 12 },
    { period: '15h - 18h', label: 'Pico da Tarde', amount: todayTotalRevenue * 0.28, pct: 28 },
  ];

  return (
    <div id="dashboard-view" className="space-y-6">
      {/* Top Banner / Quick Callout */}
      <div className="bg-gradient-to-r from-amber-700 via-amber-600 to-amber-800 rounded-3xl p-6 text-white shadow-lg relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-radial from-white/10 to-transparent pointer-events-none" />
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-amber-200 text-xs font-bold uppercase tracking-wider">
              <Sparkles className="w-4 h-4" />
              <span>Visão Operacional em Tempo Real</span>
            </div>
            <h2 className="text-2xl font-extrabold font-['Outfit']">
              Painel de Gestão da Padaria
            </h2>
            <p className="text-amber-100 text-xs sm:text-sm max-w-xl">
              Frente de Caixa ativa, controle de lotes e fornadas ao vivo, alertas de estoque e demonstrativo financeiro.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              id="btn-dash-new-sale"
              onClick={() => setActiveTab('pdv')}
              className="px-4 py-2.5 bg-white hover:bg-amber-50 text-amber-900 font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all flex items-center gap-2"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Abrir Frente de Caixa</span>
            </button>
            <button
              id="btn-dash-ask-ai"
              onClick={openAiModal}
              className="px-4 py-2.5 bg-amber-900/40 hover:bg-amber-900/60 border border-amber-300/40 text-amber-100 font-semibold text-xs sm:text-sm rounded-xl transition-all flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>Consultar IA</span>
            </button>
          </div>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Sales */}
        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs hover:border-amber-300 transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-stone-500">
              Vendas de Hoje
            </span>
            <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <p className="text-2xl font-extrabold text-stone-900 font-['Outfit']">
              {formatCurrency(todayTotalRevenue)}
            </p>
            <div className="flex items-center gap-1.5 mt-1 text-xs text-emerald-600 font-medium">
              <TrendingUp className="w-3.5 h-3.5" />
              <span>{totalOrders} pedidos realizados</span>
            </div>
          </div>
        </div>

        {/* Average Ticket */}
        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs hover:border-amber-300 transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-stone-500">
              Ticket Médio
            </span>
            <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
              <ShoppingBag className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <p className="text-2xl font-extrabold text-stone-900 font-['Outfit']">
              {formatCurrency(averageTicket)}
            </p>
            <p className="text-xs text-stone-500 mt-1">Por atendimento no balcão</p>
          </div>
        </div>

        {/* Fresh French Bread Stock */}
        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs hover:border-amber-300 transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-stone-500">
              Pão Francês
            </span>
            <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
              <Flame className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <p className="text-2xl font-extrabold text-amber-700 font-['Outfit']">
              {frenchBread ? `${frenchBread.stock} kg` : '45.5 kg'}
            </p>
            <p className="text-xs text-stone-500 mt-1">
              {activeBatches.some((b) => b.productId === 'prod-1') ? '🔥 Nova fornada no forno!' : 'Estoque regular'}
            </p>
          </div>
        </div>

        {/* Stock Alerts */}
        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs hover:border-amber-300 transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-stone-500">
              Alertas de Estoque
            </span>
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${totalAlerts > 0 ? 'bg-rose-50 text-rose-600' : 'bg-stone-50 text-stone-600'}`}>
              <AlertTriangle className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <p className={`text-2xl font-extrabold font-['Outfit'] ${totalAlerts > 0 ? 'text-rose-600' : 'text-stone-900'}`}>
              {totalAlerts} {totalAlerts === 1 ? 'item crítico' : 'itens críticos'}
            </p>
            <button
              id="btn-dash-view-stock-alerts"
              onClick={() => setActiveTab('estoque')}
              className="text-xs text-amber-700 font-semibold hover:underline mt-1 inline-flex items-center gap-1"
            >
              <span>Verificar reposição</span>
              <ArrowUpRight className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Grid: Fornadas ao Vivo & Hourly Sales Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (7 cols): Fornadas ao Vivo */}
        <div className="lg:col-span-7 space-y-6">
          {/* Active Batches Section */}
          <div className="bg-white rounded-3xl p-6 border border-stone-200 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-600 flex items-center justify-center">
                  <Flame className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-stone-900 font-['Outfit']">
                    Fornadas & Produção em Andamento
                  </h3>
                  <p className="text-xs text-stone-500">
                    Acompanhamento de fermentação, fornos e saídas
                  </p>
                </div>
              </div>
              <button
                id="btn-dash-new-batch"
                onClick={() => setActiveTab('fornadas')}
                className="px-3 py-1.5 rounded-xl bg-amber-50 text-amber-800 hover:bg-amber-100 text-xs font-bold transition-colors flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Nova Fornada</span>
              </button>
            </div>

            <div className="space-y-3">
              {activeBatches.length === 0 ? (
                <div className="p-8 text-center bg-stone-50 rounded-2xl border border-dashed border-stone-200">
                  <Flame className="w-8 h-8 text-stone-300 mx-auto mb-2" />
                  <p className="text-sm font-semibold text-stone-700">Nenhuma fornada ativa no momento</p>
                  <p className="text-xs text-stone-400 mt-1">Programe uma fornada de pão quente para o balcão.</p>
                </div>
              ) : (
                activeBatches.map((batch) => {
                  let statusBg = 'bg-stone-100 text-stone-800 border-stone-200';
                  let progressWidth = '20%';
                  let statusLabel = 'Preparando';

                  if (batch.status === 'fermentando') {
                    statusBg = 'bg-blue-50 text-blue-800 border-blue-200';
                    progressWidth = '50%';
                    statusLabel = 'Fermentando';
                  } else if (batch.status === 'assando') {
                    statusBg = 'bg-amber-50 text-amber-900 border-amber-300';
                    progressWidth = '85%';
                    statusLabel = `No Forno (${batch.temperatureTarget || 200}°C)`;
                  } else if (batch.status === 'pronto') {
                    statusBg = 'bg-emerald-50 text-emerald-900 border-emerald-300';
                    progressWidth = '100%';
                    statusLabel = '🥖 Pronto Quentinho!';
                  }

                  return (
                    <div
                      key={batch.id}
                      className="p-4 rounded-2xl border border-stone-200 hover:border-amber-300 bg-stone-50/50 hover:bg-white transition-all space-y-3"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-stone-900">{batch.productName}</span>
                            <span className="text-[10px] font-mono text-stone-400">{batch.batchCode}</span>
                          </div>
                          <p className="text-xs text-stone-500 mt-0.5">
                            Planejado: <strong className="text-stone-800">{batch.plannedQuantity} {batch.unit}</strong> • Padeiro: {batch.bakerName}
                          </p>
                        </div>

                        <span className={`px-2.5 py-1 rounded-full text-[11px] font-bold border ${statusBg}`}>
                          {statusLabel}
                        </span>
                      </div>

                      {/* Progress Bar */}
                      <div className="space-y-1">
                        <div className="w-full h-2 rounded-full bg-stone-200 overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-amber-500 to-amber-600 transition-all duration-500"
                            style={{ width: progressWidth }}
                          />
                        </div>
                        <div className="flex items-center justify-between text-[10px] text-stone-400">
                          <span>Início: {batch.startedAt}</span>
                          <span>Previsão: {batch.readyAtEstimated}</span>
                        </div>
                      </div>

                      {/* Action Advance Status */}
                      {batch.status !== 'pronto' && (
                        <div className="flex justify-end pt-1">
                          <button
                            id={`btn-advance-batch-${batch.id}`}
                            onClick={() => advanceBatchStatus(batch.id)}
                            className="px-3 py-1 bg-white hover:bg-amber-500 hover:text-white border border-stone-200 text-stone-700 text-xs font-bold rounded-lg transition-colors flex items-center gap-1"
                          >
                            <span>Avançar Etapa</span>
                            <ChevronRight className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Hourly Sales Distribution Chart Card */}
          <div className="bg-white rounded-3xl p-6 border border-stone-200 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-base font-bold text-stone-900 font-['Outfit']">
                  Vendas por Horário de Pico
                </h3>
                <p className="text-xs text-stone-500">Distribuição do fluxo de caixa durante o dia</p>
              </div>
              <span className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-stone-100 text-stone-600">
                Hoje
              </span>
            </div>

            <div className="space-y-4">
              {hourlyData.map((item) => (
                <div key={item.period} className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-stone-800">
                      {item.period} <span className="text-stone-400 font-normal">({item.label})</span>
                    </span>
                    <span className="font-mono font-semibold text-stone-700">
                      {formatCurrency(item.amount)} ({item.pct}%)
                    </span>
                  </div>
                  <div className="w-full h-3 rounded-full bg-stone-100 overflow-hidden">
                    <div
                      className="h-full bg-amber-500 rounded-full transition-all duration-700"
                      style={{ width: `${item.pct}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column (5 cols): Top Selling Products & Critical Insumos */}
        <div className="lg:col-span-5 space-y-6">
          {/* Top Sellers Card */}
          <div className="bg-white rounded-3xl p-6 border border-stone-200 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-base font-bold text-stone-900 font-['Outfit']">
                  Itens Mais Vendidos Hoje
                </h3>
                <p className="text-xs text-stone-500">Produtos de maior saída no balcão</p>
              </div>
              <button
                id="btn-view-all-products"
                onClick={() => setActiveTab('produtos')}
                className="text-xs text-amber-700 font-bold hover:underline"
              >
                Ver todos
              </button>
            </div>

            <div className="space-y-3">
              {topSellers.map((item, idx) => (
                <div
                  key={item.product.id}
                  className="flex items-center gap-3 p-2.5 rounded-2xl hover:bg-stone-50 transition-colors border border-transparent hover:border-stone-200"
                >
                  <span className="w-6 text-center text-xs font-extrabold text-stone-400 font-mono">
                    #{idx + 1}
                  </span>
                  <img
                    src={item.product.image}
                    alt={item.product.name}
                    className="w-11 h-11 rounded-xl object-cover border border-stone-200 shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold text-stone-900 truncate">
                      {item.product.name}
                    </p>
                    <p className="text-[11px] text-stone-500">
                      {formatNumber(item.quantity, item.product.unit === 'kg' ? 2 : 0)} {item.product.unit} vendidos
                    </p>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="text-xs font-mono font-bold text-stone-900">
                      {formatCurrency(item.total)}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Critical Stock Alert Box */}
          <div className="bg-stone-900 text-white rounded-3xl p-6 shadow-md border border-stone-800">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2 text-rose-400 text-xs font-bold uppercase tracking-wider">
                <AlertTriangle className="w-4 h-4" />
                <span>Insumos Críticos</span>
              </div>
              <button
                id="btn-quick-restock"
                onClick={() => setActiveTab('estoque')}
                className="text-xs text-amber-400 hover:underline font-semibold"
              >
                Repor Estoque
              </button>
            </div>

            <div className="space-y-2.5">
              {criticalIngredients.slice(0, 3).map((ing) => (
                <div
                  key={ing.id}
                  className="flex items-center justify-between p-2.5 rounded-xl bg-stone-950 border border-stone-800 text-xs"
                >
                  <div>
                    <p className="font-bold text-stone-200">{ing.name}</p>
                    <p className="text-[11px] text-stone-400">Fornecedor: {ing.supplier}</p>
                  </div>
                  <div className="text-right">
                    <span className="px-2 py-0.5 rounded text-[11px] font-mono font-bold bg-rose-950 text-rose-300 border border-rose-800">
                      {ing.currentStock} {ing.unit} (Mín: {ing.minStock})
                    </span>
                  </div>
                </div>
              ))}

              {criticalIngredients.length === 0 && (
                <div className="p-4 text-center text-xs text-stone-400">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 mx-auto mb-1" />
                  Todos os insumos estão com níveis de estoque regulares.
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
