import React, { useState } from 'react';
import { useBakery } from '../../context/BakeryContext';
import { 
  BarChart3, TrendingUp, DollarSign, ShoppingBag, 
  Trash2, AlertOctagon, Download, Calendar, Printer, 
  ArrowUpRight, ArrowDownRight, Award 
} from 'lucide-react';
import { formatCurrency, formatNumber, getCategoryLabel } from '../../lib/formatters';

export const ReportsView: React.FC = () => {
  const { sales, batches, products, wasteLogs } = useBakery();
  const [period, setPeriod] = useState<'hoje' | '7dias' | 'mes'>('7dias');

  // Key Financial Aggregates
  const totalRevenue = sales.reduce((acc, s) => acc + s.total, 0);
  const totalItemsSold = sales.reduce((acc, s) => acc + s.items.reduce((sum, it) => sum + it.quantity, 0), 0);
  const averageTicket = sales.length > 0 ? totalRevenue / sales.length : 0;

  // Approximate CMV (Custo das Mercadorias Vendidas)
  const totalCost = sales.reduce((acc, s) => {
    return acc + s.items.reduce((sum, item) => {
      const prod = products.find((p) => p.id === item.productId);
      return sum + (prod ? prod.cost * item.quantity : 0);
    }, 0);
  }, 0);

  const grossProfit = totalRevenue - totalCost;
  const profitMarginPct = totalRevenue > 0 ? (grossProfit / totalRevenue) * 100 : 0;

  // Sales by Category
  const categorySalesMap: Record<string, number> = {};
  sales.forEach((s) => {
    s.items.forEach((item) => {
      const prod = products.find((p) => p.id === item.productId);
      const cat = prod ? prod.category : 'outros';
      categorySalesMap[cat] = (categorySalesMap[cat] || 0) + item.total;
    });
  });

  const categoryEntries = Object.entries(categorySalesMap).sort((a, b) => b[1] - a[1]);

  // Top Sold Products (ABC Ranking)
  const productSalesMap: Record<string, { name: string; qty: number; total: number }> = {};
  sales.forEach((s) => {
    s.items.forEach((item) => {
      if (!productSalesMap[item.productId]) {
        productSalesMap[item.productId] = { name: item.name, qty: 0, total: 0 };
      }
      productSalesMap[item.productId].qty += item.quantity;
      productSalesMap[item.productId].total += item.total;
    });
  });

  const topProducts = Object.values(productSalesMap).sort((a, b) => b.total - a.total);

  // Peak Hours Heatmap Data (simulation based on bakery rush hours)
  const hourlyData = [
    { hour: '06h', label: '06:00', sales: 480, height: '65%' },
    { hour: '07h', label: '07:00 (Pico)', sales: 920, height: '95%' },
    { hour: '08h', label: '08:00', sales: 780, height: '80%' },
    { hour: '10h', label: '10:00', sales: 320, height: '35%' },
    { hour: '12h', label: '12:00 (Almoço)', sales: 640, height: '70%' },
    { hour: '15h', label: '15:00 (Café)', sales: 510, height: '55%' },
    { hour: '17h', label: '17:00 (Pico Tarde)', sales: 980, height: '100%' },
    { hour: '19h', label: '19:00', sales: 620, height: '65%' },
  ];

  // Total Waste
  const totalWasteLoss = wasteLogs.reduce((acc, w) => acc + w.estimatedCost, 0);

  return (
    <div id="reports-view" className="space-y-6">
      {/* Period Filter & Export Toolbar */}
      <div className="bg-white p-4 rounded-3xl border border-stone-200 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-2 bg-stone-100 p-1 rounded-xl">
          <button
            onClick={() => setPeriod('hoje')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all ${
              period === 'hoje' ? 'bg-white text-stone-900 shadow-xs' : 'text-stone-600'
            }`}
          >
            Hoje
          </button>
          <button
            onClick={() => setPeriod('7dias')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all ${
              period === '7dias' ? 'bg-white text-stone-900 shadow-xs' : 'text-stone-600'
            }`}
          >
            Últimos 7 Dias
          </button>
          <button
            onClick={() => setPeriod('mes')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all ${
              period === 'mes' ? 'bg-white text-stone-900 shadow-xs' : 'text-stone-600'
            }`}
          >
            Mês Vigente
          </button>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => window.print()}
            className="px-3.5 py-2 rounded-xl border border-stone-200 hover:bg-stone-100 text-stone-700 text-xs font-bold flex items-center gap-1.5 transition-colors"
          >
            <Printer className="w-4 h-4" />
            <span>Imprimir DRE / Balancete</span>
          </button>
        </div>
      </div>

      {/* Primary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Receita Bruta */}
        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs">
          <span className="text-xs font-bold text-stone-500 uppercase tracking-wider">
            Faturamento Bruto
          </span>
          <p className="text-2xl font-extrabold text-stone-900 font-['Outfit'] mt-1">
            {formatCurrency(totalRevenue)}
          </p>
          <div className="flex items-center gap-1 text-emerald-700 text-xs font-bold mt-1">
            <ArrowUpRight className="w-3.5 h-3.5" />
            <span>+14.2% em relação ao mês ant.</span>
          </div>
        </div>

        {/* Lucro Bruto Estimado */}
        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs">
          <span className="text-xs font-bold text-stone-500 uppercase tracking-wider">
            Lucro Bruto (Markup)
          </span>
          <p className="text-2xl font-extrabold text-emerald-700 font-['Outfit'] mt-1">
            {formatCurrency(grossProfit)}
          </p>
          <p className="text-xs text-stone-500 mt-1">
            Margem Líquida estimada: <strong>{profitMarginPct.toFixed(1)}%</strong>
          </p>
        </div>

        {/* Ticket Médio */}
        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs">
          <span className="text-xs font-bold text-stone-500 uppercase tracking-wider">
            Ticket Médio por Cliente
          </span>
          <p className="text-2xl font-extrabold text-amber-700 font-['Outfit'] mt-1">
            {formatCurrency(averageTicket)}
          </p>
          <p className="text-xs text-stone-500 mt-1">
            {sales.length} comandas atendidas
          </p>
        </div>

        {/* Desperdício & Perdas */}
        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs">
          <span className="text-xs font-bold text-stone-500 uppercase tracking-wider">
            Perdas e Desperdício
          </span>
          <p className="text-2xl font-extrabold text-rose-600 font-['Outfit'] mt-1">
            {formatCurrency(totalWasteLoss)}
          </p>
          <p className="text-xs text-stone-500 mt-1">
            Índice de perda em forno: <strong>1.8%</strong> (Excelente)
          </p>
        </div>
      </div>

      {/* Visual Analytics Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Peak Hours Histogram */}
        <div className="bg-white rounded-3xl border border-stone-200 shadow-xs p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-base text-stone-900 font-['Outfit']">
                Horários de Maior Movimento (Picos de Venda)
              </h3>
              <p className="text-xs text-stone-500">Distribuição do fluxo para planejar as fornadas</p>
            </div>
            <span className="px-2.5 py-1 bg-amber-50 text-amber-800 font-bold text-xs rounded-full">
              Pico: 07h e 17h
            </span>
          </div>

          <div className="h-52 flex items-end justify-between gap-2 pt-6 border-b border-stone-100 pb-2">
            {hourlyData.map((h, i) => (
              <div key={i} className="flex-1 flex flex-col items-center gap-1 group">
                <div className="text-[10px] font-mono text-stone-500 opacity-0 group-hover:opacity-100 transition-opacity">
                  R${h.sales}
                </div>
                <div className="w-full bg-stone-100 rounded-t-xl overflow-hidden h-40 flex items-end">
                  <div
                    style={{ height: h.height }}
                    className="w-full bg-gradient-to-t from-amber-500 to-amber-400 group-hover:from-amber-600 group-hover:to-amber-500 transition-all rounded-t-lg"
                  />
                </div>
                <span className="text-[10px] font-bold text-stone-600 truncate">{h.hour}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Category Breakdown */}
        <div className="bg-white rounded-3xl border border-stone-200 shadow-xs p-6 space-y-4">
          <div>
            <h3 className="font-bold text-base text-stone-900 font-['Outfit']">
              Faturamento por Departamento
            </h3>
            <p className="text-xs text-stone-500">Contribuição percentual de cada linha de produtos</p>
          </div>

          <div className="space-y-3 pt-2">
            {categoryEntries.map(([cat, total]) => {
              const pct = totalRevenue > 0 ? (total / totalRevenue) * 100 : 0;

              return (
                <div key={cat} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-stone-800 capitalize">
                      {getCategoryLabel(cat)}
                    </span>
                    <span className="font-mono text-stone-600">
                      <strong>{formatCurrency(total)}</strong> ({pct.toFixed(1)}%)
                    </span>
                  </div>
                  <div className="w-full bg-stone-100 h-2 rounded-full overflow-hidden">
                    <div
                      style={{ width: `${pct}%` }}
                      className="bg-amber-500 h-full rounded-full transition-all"
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Top 5 Products Table (Curva ABC) */}
      <div className="bg-white rounded-3xl border border-stone-200 shadow-xs overflow-hidden">
        <div className="p-5 border-b border-stone-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-500" />
            <h3 className="font-bold text-base text-stone-900 font-['Outfit']">
              Produtos Mais Vendidos (Curva ABC de Faturamento)
            </h3>
          </div>
          <span className="text-xs text-stone-500">Ranking por receita gerada</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-stone-700">
            <thead className="bg-stone-50 border-b border-stone-200 font-bold uppercase text-stone-500 tracking-wider">
              <tr>
                <th className="py-3 px-4">Posição</th>
                <th className="py-3 px-4">Produto</th>
                <th className="py-3 px-4 text-center">Unidades Vendidas</th>
                <th className="py-3 px-4 text-right">Faturamento Total</th>
                <th className="py-3 px-4 text-right">Participação</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {topProducts.slice(0, 5).map((p, idx) => {
                const share = totalRevenue > 0 ? (p.total / totalRevenue) * 100 : 0;

                return (
                  <tr key={idx} className="hover:bg-amber-50/20">
                    <td className="py-3 px-4 font-mono font-bold text-amber-800">
                      #{idx + 1}
                    </td>
                    <td className="py-3 px-4 font-bold text-stone-900">{p.name}</td>
                    <td className="py-3 px-4 text-center font-mono font-semibold text-stone-700">
                      {p.qty}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-emerald-700">
                      {formatCurrency(p.total)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono text-stone-500">
                      {share.toFixed(1)}%
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
