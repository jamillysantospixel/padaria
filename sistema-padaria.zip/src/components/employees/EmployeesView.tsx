import React, { useState } from 'react';
import { useBakery } from '../../context/BakeryContext';
import { 
  UserCheck, Plus, Search, Phone, Mail, Clock, 
  DollarSign, Shield, Edit2, Check, X, Calendar 
} from 'lucide-react';
import { formatCurrency } from '../../lib/formatters';
import { Employee, UserRole } from '../../types';

export const EmployeesView: React.FC = () => {
  const { employees, addEmployee, updateEmployee } = useBakery();
  const [searchQuery, setSearchQuery] = useState('');

  const [isAddOpen, setIsAddOpen] = useState(false);
  const [editingEmpId, setEditingEmpId] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    name: '',
    role: 'caixa' as UserRole,
    roleTitle: 'Atendente de Balcão & Caixa',
    phone: '',
    email: '',
    shift: 'manha' as 'manha' | 'tarde' | 'noite' | 'integral',
    shiftHours: '06:00 - 14:30',
    salary: 2200.0,
    status: 'ativo' as 'ativo' | 'folga' | 'ferias',
    hireDate: '2026-08-24',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
  });

  const filteredEmployees = employees.filter((emp) =>
    emp.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    emp.roleTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
    emp.phone.includes(searchQuery)
  );

  const totalPayroll = employees.reduce((acc, e) => acc + e.salary, 0);
  const activeCount = employees.filter((e) => e.status === 'ativo').length;

  const handleOpenAdd = () => {
    setEditingEmpId(null);
    setFormData({
      name: '',
      role: 'caixa',
      roleTitle: 'Atendente de Balcão & Caixa',
      phone: '(11) 9',
      email: '',
      shift: 'manha',
      shiftHours: '06:00 - 14:30',
      salary: 2200.0,
      status: 'ativo',
      hireDate: new Date().toISOString().split('T')[0],
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
    });
    setIsAddOpen(true);
  };

  const handleOpenEdit = (emp: Employee) => {
    setEditingEmpId(emp.id);
    setFormData({
      name: emp.name,
      role: emp.role,
      roleTitle: emp.roleTitle,
      phone: emp.phone,
      email: emp.email,
      shift: emp.shift,
      shiftHours: emp.shiftHours,
      salary: emp.salary,
      status: emp.status,
      hireDate: emp.hireDate,
      avatar: emp.avatar,
    });
    setIsAddOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingEmpId) {
      updateEmployee(editingEmpId, formData);
    } else {
      addEmployee(formData);
    }
    setIsAddOpen(false);
  };

  return (
    <div id="employees-view" className="space-y-6">
      {/* Top Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs">
          <span className="text-xs font-bold text-stone-500 uppercase tracking-wider">
            Equipe Cadastrada
          </span>
          <p className="text-2xl font-extrabold text-stone-900 font-['Outfit'] mt-1">
            {employees.length} colaboradores
          </p>
          <p className="text-xs text-emerald-700 font-semibold mt-1">
            {activeCount} presentes em turno hoje
          </p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs">
          <span className="text-xs font-bold text-stone-500 uppercase tracking-wider">
            Folha de Pagamento Estimada
          </span>
          <p className="text-2xl font-extrabold text-stone-900 font-['Outfit'] mt-1">
            {formatCurrency(totalPayroll)} /mês
          </p>
          <p className="text-xs text-stone-500 mt-1">
            Salários base de produção e atendimento
          </p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-stone-500 uppercase tracking-wider">
              Gestão de Equipe
            </span>
            <p className="text-xs text-stone-600 mt-1">Turnos, escalas e cargos</p>
          </div>
          <button
            id="btn-add-employee"
            onClick={handleOpenAdd}
            className="px-4 py-2.5 bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center gap-1.5 shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Novo Colaborador</span>
          </button>
        </div>
      </div>

      {/* Search Header */}
      <div className="bg-white p-4 rounded-3xl border border-stone-200 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-96">
          <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Buscar colaborador ou cargo..."
            className="w-full pl-10 pr-4 py-2 rounded-xl bg-stone-50 border border-stone-200 text-stone-900 text-xs focus:outline-none focus:border-amber-500"
          />
        </div>
      </div>

      {/* Employee Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {filteredEmployees.map((emp) => (
          <div
            key={emp.id}
            className="bg-white rounded-3xl border border-stone-200 hover:border-amber-300 shadow-xs p-5 space-y-4 transition-all"
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <img
                  src={emp.avatar}
                  alt={emp.name}
                  className="w-12 h-12 rounded-2xl object-cover border border-stone-200 shrink-0"
                />
                <div>
                  <h4 className="font-bold text-sm text-stone-900 leading-snug">{emp.name}</h4>
                  <p className="text-xs text-amber-700 font-semibold">{emp.roleTitle}</p>
                </div>
              </div>

              <span
                className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                  emp.status === 'ativo'
                    ? 'bg-emerald-100 text-emerald-800'
                    : emp.status === 'folga'
                    ? 'bg-amber-100 text-amber-800'
                    : 'bg-stone-100 text-stone-600'
                }`}
              >
                {emp.status}
              </span>
            </div>

            <div className="p-3 bg-stone-50 rounded-2xl border border-stone-100 space-y-2 text-xs text-stone-600">
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1 text-stone-500">
                  <Clock className="w-3.5 h-3.5 text-stone-400" />
                  Turno:
                </span>
                <strong className="text-stone-800">{emp.shiftHours}</strong>
              </div>

              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1 text-stone-500">
                  <Phone className="w-3.5 h-3.5 text-stone-400" />
                  Telefone:
                </span>
                <span className="font-mono text-stone-800">{emp.phone}</span>
              </div>

              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1 text-stone-500">
                  <DollarSign className="w-3.5 h-3.5 text-stone-400" />
                  Salário Base:
                </span>
                <strong className="font-mono text-stone-800">{formatCurrency(emp.salary)}</strong>
              </div>
            </div>

            <div className="flex items-center justify-between pt-1 text-xs">
              <span className="text-[11px] text-stone-400">Admitido em: {emp.hireDate}</span>
              <button
                onClick={() => handleOpenEdit(emp)}
                className="p-1.5 text-stone-500 hover:text-amber-700 hover:bg-stone-100 rounded-lg transition-colors flex items-center gap-1"
              >
                <Edit2 className="w-3.5 h-3.5" />
                <span className="text-xs font-semibold">Editar</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Add / Edit Employee Modal */}
      {isAddOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 space-y-5 shadow-2xl animate-in fade-in zoom-in-95 max-h-[90vh] overflow-y-auto custom-scrollbar">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <h3 className="font-bold text-base text-stone-900 font-['Outfit']">
                {editingEmpId ? 'Editar Dados do Colaborador' : 'Cadastrar Novo Colaborador'}
              </h3>
              <button
                onClick={() => setIsAddOpen(false)}
                className="p-1 rounded-lg text-stone-400 hover:text-stone-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Nome Completo *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Carlos Arnaldo Silva"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-stone-200 focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Tipo de Acesso (Perfil)
                  </label>
                  <select
                    value={formData.role}
                    onChange={(e) => setFormData({ ...formData, role: e.target.value as UserRole })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-stone-200 focus:border-amber-500 focus:outline-none"
                  >
                    <option value="caixa">Caixa / Atendente</option>
                    <option value="padeiro">Padeiro / Confeiteiro</option>
                    <option value="gerente">Gerente</option>
                    <option value="admin">Administrador</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Título do Cargo
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Ex: Padeiro Chefe Manhã"
                    value={formData.roleTitle}
                    onChange={(e) => setFormData({ ...formData, roleTitle: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-stone-200 focus:border-amber-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Telefone / WhatsApp *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="(11) 99999-0000"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-stone-200 focus:border-amber-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Horário da Escala
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="05:00 - 13:20"
                    value={formData.shiftHours}
                    onChange={(e) => setFormData({ ...formData, shiftHours: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-stone-200 focus:border-amber-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Salário Base (R$)
                  </label>
                  <input
                    type="number"
                    step="100"
                    value={formData.salary}
                    onChange={(e) => setFormData({ ...formData, salary: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 text-xs font-mono rounded-xl border border-stone-200 focus:border-amber-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Status Atual
                  </label>
                  <select
                    value={formData.status}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-stone-200 focus:border-amber-500 focus:outline-none"
                  >
                    <option value="ativo">Ativo / Trabalhando</option>
                    <option value="folga">Folga da Escala</option>
                    <option value="ferias">Em Férias</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  URL da Foto / Avatar
                </label>
                <input
                  type="url"
                  value={formData.avatar}
                  onChange={(e) => setFormData({ ...formData, avatar: e.target.value })}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-stone-200 focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddOpen(false)}
                  className="flex-1 py-2.5 rounded-xl border border-stone-300 text-stone-700 font-bold text-xs hover:bg-stone-100"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs shadow-md"
                >
                  Salvar Colaborador
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
