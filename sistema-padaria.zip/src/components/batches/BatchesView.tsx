import React, { useState } from 'react';
import { useBakery } from '../../context/BakeryContext';
import { 
  Flame, Plus, Clock, CheckCircle2, AlertTriangle, 
  ChevronRight, Thermometer, User, RefreshCw, X, Sparkles, Bell 
} from 'lucide-react';
import { BakeryBatch, BatchStatus } from '../../types';
import { sounds } from '../../lib/audio';

export const BatchesView: React.FC = () => {
  const { batches, addBatch, advanceBatchStatus, products, employees } = useBakery();
  const [isAddOpen, setIsAddOpen] = useState(false);

  // Modal Finish with Waste registration
  const [finishingBatch, setFinishingBatch] = useState<BakeryBatch | null>(null);
  const [actualProduced, setActualProduced] = useState<number>(0);
  const [wastedQty, setWastedQty] = useState<number>(0);
  const [wasteReason, setWasteReason] = useState<string>('Ponta queimada / formato irregular');

  // Form for new batch
  const [selectedProductId, setSelectedProductId] = useState<string>(products[0]?.id || '');
  const [plannedQty, setPlannedQty] = useState<number>(200);
  const [bakerName, setBakerName] = useState<string>('Arnaldo Ribeiro');
  const [estimatedMinutes, setEstimatedMinutes] = useState<number>(35);
  const [tempTarget, setTempTarget] = useState<number>(220);

  const bakeryProducts = products.filter((p) => p.isBakeryProduced);
  const bakers = employees.filter((e) => e.role === 'padeiro' || e.role === 'admin');

  const handleStartBatch = (e: React.FormEvent) => {
    e.preventDefault();
    const prod = products.find((p) => p.id === selectedProductId);
    if (!prod) return;

    const now = new Date();
    const readyDate = new Date(now.getTime() + estimatedMinutes * 60000);
    const readyTimeStr = `${String(readyDate.getHours()).padStart(2, '0')}:${String(readyDate.getMinutes()).padStart(2, '0')}`;

    addBatch({
      productId: prod.id,
      productName: prod.name,
      plannedQuantity: plannedQty,
      unit: prod.unit,
      status: 'preparando',
      bakerName,
      readyAtEstimated: readyTimeStr,
      temperatureTarget: tempTarget,
    });

    setIsAddOpen(false);
  };

  const handleOpenFinishModal = (batch: BakeryBatch) => {
    setFinishingBatch(batch);
    setActualProduced(batch.plannedQuantity);
    setWastedQty(0);
    setWasteReason('Sobras normais de corte');
  };

  const handleConfirmFinish = () => {
    if (finishingBatch) {
      advanceBatchStatus(finishingBatch.id, actualProduced, wastedQty, wasteReason);
      setFinishingBatch(null);
    }
  };

  const columns: { id: BatchStatus; title: string; icon: any; color: string }[] = [
    { id: 'preparando', title: '1. Preparando Massa', icon: Clock, color: 'border-stone-300 bg-stone-50' },
    { id: 'fermentando', title: '2. Fermentando', icon: Clock, color: 'border-blue-300 bg-blue-50/50' },
    { id: 'assando', title: '3. No Forno', icon: Flame, color: 'border-amber-300 bg-amber-50/50' },
    { id: 'pronto', title: '4. Pronto no Balcão!', icon: CheckCircle2, color: 'border-emerald-300 bg-emerald-50/50' },
  ];

  return (
    <div id="batches-view" className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-stone-900 via-stone-800 to-amber-950 rounded-3xl p-6 text-white shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-amber-400 text-xs font-bold uppercase tracking-wider">
            <Flame className="w-4 h-4" />
            <span>Gestão de Fornos & Produção Artesanal</span>
          </div>
          <h2 className="text-2xl font-extrabold font-['Outfit']">
            Quadro de Fornadas ao Vivo
          </h2>
          <p className="text-stone-300 text-xs sm:text-sm max-w-xl">
            Monitore o ciclo de cada fornada para ter pão quente sempre fresco no balcão e controlar as perdas de produção.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            id="btn-sound-alarm-test"
            onClick={() => sounds.playOvenBell()}
            className="px-3.5 py-2.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-semibold flex items-center gap-1.5 border border-stone-700 transition-colors"
            title="Tocar sino do forno"
          >
            <Bell className="w-4 h-4 text-amber-400" />
            <span className="hidden sm:inline">Sino do Forno</span>
          </button>

          <button
            id="btn-open-new-batch-modal"
            onClick={() => setIsAddOpen(true)}
            className="px-4 py-2.5 bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all flex items-center gap-1.5 shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Iniciar Nova Fornada</span>
          </button>
        </div>
      </div>

      {/* Kanban Pipeline Columns */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        {columns.map((col) => {
          const colBatches = batches.filter((b) => b.status === col.id);
          const Icon = col.icon;

          return (
            <div
              key={col.id}
              className={`rounded-3xl border ${col.color} p-4 flex flex-col min-h-[480px] shadow-xs`}
            >
              <div className="flex items-center justify-between pb-3 border-b border-black/5 mb-3">
                <div className="flex items-center gap-2">
                  <Icon className="w-4 h-4 text-amber-600" />
                  <h3 className="font-bold text-sm text-stone-900 font-['Outfit']">
                    {col.title}
                  </h3>
                </div>
                <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-full bg-white text-stone-700 shadow-2xs">
                  {colBatches.length}
                </span>
              </div>

              {/* Batch Cards */}
              <div className="flex-1 space-y-3 overflow-y-auto pr-1 custom-scrollbar">
                {colBatches.map((batch) => (
                  <div
                    key={batch.id}
                    className="bg-white rounded-2xl p-4 border border-stone-200 shadow-xs space-y-3 hover:border-amber-400 transition-all group"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <span className="text-[10px] font-mono text-stone-400 uppercase">
                          {batch.batchCode}
                        </span>
                        <h4 className="text-xs font-bold text-stone-900 leading-snug">
                          {batch.productName}
                        </h4>
                      </div>
                      {batch.temperatureTarget && (
                        <span className="text-[10px] font-mono font-bold text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded flex items-center gap-0.5 shrink-0">
                          <Thermometer className="w-3 h-3" />
                          {batch.temperatureTarget}°C
                        </span>
                      )}
                    </div>

                    <div className="space-y-1 text-xs text-stone-500">
                      <div className="flex items-center justify-between">
                        <span>Quantidade:</span>
                        <strong className="text-stone-800 font-mono">
                          {batch.plannedQuantity} {batch.unit}
                        </strong>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>Padeiro:</span>
                        <span className="text-stone-700">{batch.bakerName.split(' ')[0]}</span>
                      </div>
                      <div className="flex items-center justify-between text-[11px]">
                        <span>Iniciado às: {batch.startedAt}</span>
                        <span className="text-amber-700 font-bold">
                          Previsão: {batch.readyAtEstimated}
                        </span>
                      </div>
                    </div>

                    {/* Progress / Actions */}
                    <div className="pt-2 border-t border-stone-100 flex items-center justify-between gap-2">
                      {batch.status === 'assando' ? (
                        <button
                          id={`btn-ready-batch-${batch.id}`}
                          onClick={() => handleOpenFinishModal(batch)}
                          className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center gap-1.5"
                        >
                          <Flame className="w-3.5 h-3.5" />
                          <span>Tirar do Forno (Pronto)</span>
                        </button>
                      ) : batch.status !== 'pronto' ? (
                        <button
                          id={`btn-advance-status-${batch.id}`}
                          onClick={() => advanceBatchStatus(batch.id)}
                          className="w-full py-2 bg-stone-100 hover:bg-amber-500 hover:text-white text-stone-800 font-bold text-xs rounded-xl transition-colors flex items-center justify-center gap-1"
                        >
                          <span>Avançar Etapa</span>
                          <ChevronRight className="w-3.5 h-3.5" />
                        </button>
                      ) : (
                        <div className="w-full flex items-center justify-between text-[11px] text-emerald-800 font-semibold bg-emerald-50 px-2.5 py-1.5 rounded-xl border border-emerald-200">
                          <span>Disponível no Balcão</span>
                          <button
                            onClick={() => advanceBatchStatus(batch.id)}
                            className="text-stone-400 hover:text-stone-700 text-[10px] underline"
                          >
                            Esgotar
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                ))}

                {colBatches.length === 0 && (
                  <div className="h-40 border border-dashed border-stone-200 rounded-2xl flex items-center justify-center text-center p-4 text-xs text-stone-400">
                    Nenhuma fornada nesta etapa
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* New Batch Modal */}
      {isAddOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 space-y-5 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div className="flex items-center gap-2">
                <Flame className="w-5 h-5 text-amber-600" />
                <h3 className="font-bold text-base text-stone-900 font-['Outfit']">
                  Iniciar Nova Fornada
                </h3>
              </div>
              <button
                onClick={() => setIsAddOpen(false)}
                className="p-1 rounded-lg text-stone-400 hover:text-stone-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleStartBatch} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Produto da Fornada *
                </label>
                <select
                  value={selectedProductId}
                  onChange={(e) => setSelectedProductId(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-stone-200 focus:border-amber-500 focus:outline-none"
                >
                  {bakeryProducts.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({p.unit})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Quantidade Prevista *
                  </label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={plannedQty}
                    onChange={(e) => setPlannedQty(parseInt(e.target.value, 10) || 1)}
                    className="w-full px-3 py-2 text-xs font-mono font-bold rounded-xl border border-stone-200 focus:border-amber-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Tempo Total (min)
                  </label>
                  <input
                    type="number"
                    min="5"
                    value={estimatedMinutes}
                    onChange={(e) => setEstimatedMinutes(parseInt(e.target.value, 10) || 30)}
                    className="w-full px-3 py-2 text-xs font-mono rounded-xl border border-stone-200 focus:border-amber-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Padeiro Responsável
                  </label>
                  <select
                    value={bakerName}
                    onChange={(e) => setBakerName(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-stone-200 focus:border-amber-500 focus:outline-none"
                  >
                    {bakers.map((b) => (
                      <option key={b.id} value={b.name}>
                        {b.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Temp. do Forno (°C)
                  </label>
                  <input
                    type="number"
                    value={tempTarget}
                    onChange={(e) => setTempTarget(parseInt(e.target.value, 10) || 200)}
                    className="w-full px-3 py-2 text-xs font-mono rounded-xl border border-stone-200 focus:border-amber-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddOpen(false)}
                  className="flex-1 py-2.5 rounded-xl border border-stone-300 text-stone-700 font-bold text-xs hover:bg-stone-100"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs shadow-md"
                >
                  Iniciar Fornada
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Finish Batch & Waste Registration Modal */}
      {finishingBatch && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 space-y-5 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div>
                <h3 className="font-bold text-base text-stone-900 font-['Outfit']">
                  Concluir Fornada & Conferência
                </h3>
                <p className="text-xs text-stone-500">{finishingBatch.productName}</p>
              </div>
              <button
                onClick={() => setFinishingBatch(null)}
                className="p-1 rounded-lg text-stone-400 hover:text-stone-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Produzidos Perfeitos ({finishingBatch.unit})
                  </label>
                  <input
                    type="number"
                    value={actualProduced}
                    onChange={(e) => setActualProduced(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 text-xs font-mono font-bold rounded-xl border border-emerald-300 focus:border-emerald-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-rose-700 mb-1">
                    Perdas / Descarte ({finishingBatch.unit})
                  </label>
                  <input
                    type="number"
                    value={wastedQty}
                    onChange={(e) => setWastedQty(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 text-xs font-mono font-bold rounded-xl border border-rose-300 text-rose-700 focus:border-rose-500 focus:outline-none"
                  />
                </div>
              </div>

              {wastedQty > 0 && (
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Motivo da Perda (para relatório de desperdício)
                  </label>
                  <input
                    type="text"
                    value={wasteReason}
                    onChange={(e) => setWasteReason(e.target.value)}
                    placeholder="Ex: Queimou na lateral do forno"
                    className="w-full px-3 py-2 text-xs rounded-xl border border-stone-200 focus:border-amber-500 focus:outline-none"
                  />
                </div>
              )}

              <div className="p-3 rounded-2xl bg-amber-50 border border-amber-200 text-xs text-amber-900">
                Ao confirmar, o estoque do produto será automaticamente incrementado em <strong>+{actualProduced} {finishingBatch.unit}</strong> no balcão.
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setFinishingBatch(null)}
                  className="flex-1 py-2.5 rounded-xl border border-stone-300 text-stone-700 font-bold text-xs hover:bg-stone-100"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={handleConfirmFinish}
                  className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md"
                >
                  Liberar no Balcão
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
