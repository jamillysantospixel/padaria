import React, { useState } from 'react';
import { useBakery } from '../../context/BakeryContext';
import { 
  DollarSign, ArrowDownCircle, ArrowUpCircle, Lock, 
  Unlock, Printer, ShieldAlert, CheckCircle2, History, Plus, X 
} from 'lucide-react';
import { formatCurrency, formatDateTime } from '../../lib/formatters';
import { CashRegisterMovement } from '../../types';

export const CashRegisterView: React.FC = () => {
  const { cashRegister, openCashRegister, closeCashRegister, addCashMovement, sales } = useBakery();

  // Modals
  const [isOpenModal, setIsOpenModal] = useState(false);
  const [initialAmountInput, setInitialAmountInput] = useState<number>(200);

  const [isCloseModal, setIsCloseModal] = useState(false);
  const [reportedCashInput, setReportedCashInput] = useState<number>(0);
  const [closeNotesInput, setCloseNotesInput] = useState<string>('');

  const [isMovementModal, setIsMovementModal] = useState(false);
  const [movementType, setMovementType] = useState<'suprimento' | 'sangria'>('sangria');
  const [movementAmount, setMovementAmount] = useState<number>(50);
  const [movementDesc, setMovementDesc] = useState<string>('Sangria para o cofre de segurança');

  // Breakdown of sales by payment method for the current register
  const salesCash = cashRegister.movements
    .filter((m) => m.type === 'venda' && m.paymentMethod === 'dinheiro')
    .reduce((acc, m) => acc + m.amount, 0);

  const salesPix = cashRegister.movements
    .filter((m) => m.type === 'venda' && m.paymentMethod === 'pix')
    .reduce((acc, m) => acc + m.amount, 0);

  const salesCards = cashRegister.movements
    .filter((m) => m.type === 'venda' && (m.paymentMethod === 'debito' || m.paymentMethod === 'credito'))
    .reduce((acc, m) => acc + m.amount, 0);

  const salesFiado = cashRegister.movements
    .filter((m) => m.type === 'venda' && m.paymentMethod === 'fiado')
    .reduce((acc, m) => acc + m.amount, 0);

  const totalSuprimentos = cashRegister.movements
    .filter((m) => m.type === 'suprimento')
    .reduce((acc, m) => acc + m.amount, 0);

  const totalSangrias = cashRegister.movements
    .filter((m) => m.type === 'sangria')
    .reduce((acc, m) => acc + m.amount, 0);

  const expectedCashInDrawer = cashRegister.initialAmount + totalSuprimentos - totalSangrias + salesCash;

  const handleOpenRegister = (e: React.FormEvent) => {
    e.preventDefault();
    openCashRegister(initialAmountInput);
    setIsOpenModal(false);
  };

  const handleCloseRegister = (e: React.FormEvent) => {
    e.preventDefault();
    closeCashRegister(reportedCashInput, closeNotesInput);
    setIsCloseModal(false);
  };

  const handleCreateMovement = (e: React.FormEvent) => {
    e.preventDefault();
    addCashMovement(movementType, movementAmount, movementDesc);
    setIsMovementModal(false);
  };

  return (
    <div id="cash-register-view" className="space-y-6">
      {/* Top Status & Summary Banner */}
      <div className="bg-white rounded-3xl border border-stone-200 shadow-xs p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-white shadow-md shrink-0 ${
            cashRegister.status === 'aberto' ? 'bg-emerald-600' : 'bg-stone-700'
          }`}>
            {cashRegister.status === 'aberto' ? <Unlock className="w-7 h-7" /> : <Lock className="w-7 h-7" />}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-extrabold text-stone-900 font-['Outfit']">
                {cashRegister.status === 'aberto' ? 'Caixa Aberto (Turno em Andamento)' : 'Caixa Fechado'}
              </h2>
              <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold uppercase ${
                cashRegister.status === 'aberto' ? 'bg-emerald-100 text-emerald-800' : 'bg-stone-200 text-stone-700'
              }`}>
                {cashRegister.status}
              </span>
            </div>
            <p className="text-xs text-stone-500 mt-0.5">
              Aberto em: <strong>{cashRegister.openedAt}</strong> por <strong>{cashRegister.openedBy}</strong>
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 flex-wrap">
          {cashRegister.status === 'aberto' ? (
            <>
              <button
                id="btn-open-sangria-modal"
                onClick={() => {
                  setMovementType('sangria');
                  setMovementDesc('Sangria para cofre');
                  setIsMovementModal(true);
                }}
                className="px-3.5 py-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-bold transition-colors flex items-center gap-1.5"
              >
                <ArrowUpCircle className="w-4 h-4 text-rose-600" />
                <span>Sangria (Retirada)</span>
              </button>

              <button
                id="btn-open-suprimento-modal"
                onClick={() => {
                  setMovementType('suprimento');
                  setMovementDesc('Reforço de moedas/troco');
                  setIsMovementModal(true);
                }}
                className="px-3.5 py-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-bold transition-colors flex items-center gap-1.5"
              >
                <ArrowDownCircle className="w-4 h-4 text-emerald-600" />
                <span>Suprimento (Entrada)</span>
              </button>

              <button
                id="btn-close-register-modal"
                onClick={() => {
                  setReportedCashInput(expectedCashInDrawer);
                  setIsCloseModal(true);
                }}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shadow-xs transition-colors flex items-center gap-1.5"
              >
                <Lock className="w-4 h-4" />
                <span>Fechar Caixa</span>
              </button>
            </>
          ) : (
            <button
              id="btn-open-register-modal"
              onClick={() => setIsOpenModal(true)}
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-md transition-colors flex items-center gap-1.5"
            >
              <Unlock className="w-4 h-4" />
              <span>Abrir Novo Caixa</span>
            </button>
          )}

          <button
            onClick={() => window.print()}
            className="p-2 rounded-xl border border-stone-200 hover:bg-stone-100 text-stone-600"
            title="Imprimir Relatório de Caixa"
          >
            <Printer className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Financial Breakdown Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Dinheiro Físico em Gaveta */}
        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs">
          <span className="text-xs font-bold text-stone-500 uppercase tracking-wider">
            Dinheiro Físico em Gaveta
          </span>
          <p className="text-2xl font-extrabold text-stone-900 font-['Outfit'] mt-1">
            {formatCurrency(expectedCashInDrawer)}
          </p>
          <p className="text-[11px] text-stone-400 mt-1">
            Fundo inicial: {formatCurrency(cashRegister.initialAmount)} + Vendas Dinheiro: {formatCurrency(salesCash)}
          </p>
        </div>

        {/* Vendas PIX */}
        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs">
          <span className="text-xs font-bold text-stone-500 uppercase tracking-wider">
            Recebido em PIX
          </span>
          <p className="text-2xl font-extrabold text-amber-700 font-['Outfit'] mt-1">
            {formatCurrency(salesPix)}
          </p>
          <p className="text-[11px] text-stone-400 mt-1">Direto na conta bancária</p>
        </div>

        {/* Cartões Crédito & Débito */}
        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs">
          <span className="text-xs font-bold text-stone-500 uppercase tracking-wider">
            Cartões (Débito/Crédito)
          </span>
          <p className="text-2xl font-extrabold text-blue-700 font-['Outfit'] mt-1">
            {formatCurrency(salesCards)}
          </p>
          <p className="text-[11px] text-stone-400 mt-1">Total em maquininhas TEF/POS</p>
        </div>

        {/* Total Geral de Vendas do Turno */}
        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs">
          <span className="text-xs font-bold text-stone-500 uppercase tracking-wider">
            Total de Vendas no Turno
          </span>
          <p className="text-2xl font-extrabold text-emerald-700 font-['Outfit'] mt-1">
            {formatCurrency(cashRegister.totalSales)}
          </p>
          <p className="text-[11px] text-stone-400 mt-1">
            {cashRegister.salesCount} vendas realizadas
          </p>
        </div>
      </div>

      {/* Movements History */}
      <div className="bg-white rounded-3xl border border-stone-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-stone-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <History className="w-5 h-5 text-amber-600" />
            <h3 className="font-bold text-base text-stone-900 font-['Outfit']">
              Movimentações e Extrato do Caixa
            </h3>
          </div>
          <span className="text-xs text-stone-500">
            {cashRegister.movements.length} lançamentos
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-stone-700">
            <thead className="bg-stone-50 border-b border-stone-200 font-bold uppercase text-stone-500 tracking-wider">
              <tr>
                <th className="py-3 px-4">Horário</th>
                <th className="py-3 px-4">Tipo</th>
                <th className="py-3 px-4">Descrição</th>
                <th className="py-3 px-4 text-right">Valor</th>
                <th className="py-3 px-4">Operador</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {cashRegister.movements.map((mov) => {
                let badge = 'bg-stone-100 text-stone-800';
                let sign = '+';
                if (mov.type === 'sangria') {
                  badge = 'bg-rose-100 text-rose-800';
                  sign = '-';
                } else if (mov.type === 'suprimento') {
                  badge = 'bg-emerald-100 text-emerald-800';
                  sign = '+';
                } else if (mov.type === 'venda') {
                  badge = 'bg-amber-100 text-amber-900';
                  sign = '+';
                }

                return (
                  <tr key={mov.id} className="hover:bg-amber-50/20">
                    <td className="py-3 px-4 font-mono text-stone-500">{mov.timestamp}</td>
                    <td className="py-3 px-4">
                      <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase ${badge}`}>
                        {mov.type}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-medium text-stone-900">{mov.description}</td>
                    <td className={`py-3 px-4 text-right font-mono font-bold ${
                      mov.type === 'sangria' ? 'text-rose-600' : 'text-emerald-700'
                    }`}>
                      {sign} {formatCurrency(mov.amount)}
                    </td>
                    <td className="py-3 px-4 text-stone-500">{mov.operatorName}</td>
                  </tr>
                );
              })}

              {cashRegister.movements.length === 0 && (
                <tr>
                  <td colSpan={5} className="py-8 text-center text-xs text-stone-400">
                    Nenhuma movimentação registrada neste turno de caixa.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Open Register Modal */}
      {isOpenModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 space-y-5 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div className="flex items-center gap-2">
                <Unlock className="w-5 h-5 text-emerald-600" />
                <h3 className="font-bold text-base text-stone-900 font-['Outfit']">
                  Abertura de Caixa
                </h3>
              </div>
              <button
                onClick={() => setIsOpenModal(false)}
                className="p-1 rounded-lg text-stone-400 hover:text-stone-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleOpenRegister} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Fundo de Troco Inicial (R$) *
                </label>
                <input
                  type="number"
                  step="10.00"
                  required
                  value={initialAmountInput}
                  onChange={(e) => setInitialAmountInput(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 text-base font-mono font-bold rounded-xl border border-emerald-300 focus:border-emerald-500 focus:outline-none"
                />
                <p className="text-xs text-stone-500 mt-1">
                  Valor em cédulas e moedas inserido na gaveta para troco.
                </p>
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsOpenModal(false)}
                  className="flex-1 py-2.5 rounded-xl border border-stone-300 text-stone-700 font-bold text-xs hover:bg-stone-100"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md"
                >
                  Confirmar Abertura
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Movement Modal (Sangria / Suprimento) */}
      {isMovementModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 space-y-5 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <h3 className="font-bold text-base text-stone-900 font-['Outfit']">
                {movementType === 'sangria' ? 'Sangria (Retirada de Caixa)' : 'Suprimento (Entrada de Troco)'}
              </h3>
              <button
                onClick={() => setIsMovementModal(false)}
                className="p-1 rounded-lg text-stone-400 hover:text-stone-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateMovement} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Valor da Movimentação (R$) *
                </label>
                <input
                  type="number"
                  step="5.00"
                  required
                  value={movementAmount}
                  onChange={(e) => setMovementAmount(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 text-base font-mono font-bold rounded-xl border border-stone-300 focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Motivo / Observação
                </label>
                <input
                  type="text"
                  required
                  value={movementDesc}
                  onChange={(e) => setMovementDesc(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-stone-200 focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsMovementModal(false)}
                  className="flex-1 py-2.5 rounded-xl border border-stone-300 text-stone-700 font-bold text-xs hover:bg-stone-100"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className={`flex-1 py-2.5 rounded-xl text-white font-bold text-xs shadow-md ${
                    movementType === 'sangria' ? 'bg-rose-600 hover:bg-rose-700' : 'bg-emerald-600 hover:bg-emerald-700'
                  }`}
                >
                  Confirmar Lançamento
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Close Register Modal */}
      {isCloseModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 space-y-5 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div className="flex items-center gap-2">
                <Lock className="w-5 h-5 text-rose-600" />
                <h3 className="font-bold text-base text-stone-900 font-['Outfit']">
                  Fechamento de Turno de Caixa
                </h3>
              </div>
              <button
                onClick={() => setIsCloseModal(false)}
                className="p-1 rounded-lg text-stone-400 hover:text-stone-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCloseRegister} className="space-y-4">
              <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-1 text-xs">
                <div className="flex justify-between text-stone-600">
                  <span>Valor Calculado no Sistema:</span>
                  <span className="font-mono font-bold">{formatCurrency(expectedCashInDrawer)}</span>
                </div>
                <div className="flex justify-between text-stone-500">
                  <span>Total de Vendas do Turno:</span>
                  <span className="font-mono">{formatCurrency(cashRegister.totalSales)}</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Valor Contado na Gaveta (R$) *
                </label>
                <input
                  type="number"
                  step="0.50"
                  required
                  value={reportedCashInput}
                  onChange={(e) => setReportedCashInput(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 text-base font-mono font-bold rounded-xl border border-rose-300 focus:border-rose-500 focus:outline-none"
                />
                <p className="text-xs text-stone-500 mt-1">
                  Diferença (Quebra):{' '}
                  <strong className={reportedCashInput - expectedCashInDrawer < 0 ? 'text-rose-600' : 'text-emerald-600'}>
                    {formatCurrency(reportedCashInput - expectedCashInDrawer)}
                  </strong>
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Observações do Fechamento
                </label>
                <textarea
                  rows={2}
                  value={closeNotesInput}
                  onChange={(e) => setCloseNotesInput(e.target.value)}
                  placeholder="Ex: Turno encerrado sem divergências..."
                  className="w-full px-3 py-2 text-xs rounded-xl border border-stone-200 focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsCloseModal(false)}
                  className="flex-1 py-2.5 rounded-xl border border-stone-300 text-stone-700 font-bold text-xs hover:bg-stone-100"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-md"
                >
                  Concluir Fechamento
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
