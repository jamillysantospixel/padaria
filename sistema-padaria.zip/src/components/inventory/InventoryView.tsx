import React, { useState } from 'react';
import { useBakery } from '../../context/BakeryContext';
import { 
  Package, Plus, Search, AlertTriangle, ArrowDownRight, 
  ArrowUpRight, Calendar, DollarSign, Truck, X, Check 
} from 'lucide-react';
import { formatCurrency, formatDateTime } from '../../lib/formatters';
import { Ingredient } from '../../types';

export const InventoryView: React.FC = () => {
  const { ingredients, addIngredient, restockIngredient, stockMovements } = useBakery();
  const [activeTab, setActiveTab] = useState<'insumos' | 'movimentacoes'>('insumos');
  const [searchQuery, setSearchQuery] = useState('');

  // Restock Modal
  const [restockItem, setRestockItem] = useState<Ingredient | null>(null);
  const [restockQty, setRestockQty] = useState<number>(10);
  const [restockCost, setRestockCost] = useState<number>(0);
  const [restockSupplier, setRestockSupplier] = useState<string>('');

  // New Insumo Modal
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [newInsumo, setNewInsumo] = useState({
    name: '',
    category: 'Farinhas & Grãos',
    currentStock: 10,
    minStock: 5,
    unit: 'un' as 'kg' | 'g' | 'litro' | 'ml' | 'un',
    unitCost: 50.0,
    supplier: 'Distribuidora Panisul',
    expiryDate: '2026-12-31',
    lastRestockDate: '2026-08-24',
  });

  const filteredIngredients = ingredients.filter((ing) =>
    ing.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    ing.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
    ing.supplier.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const totalStockValue = ingredients.reduce((acc, ing) => acc + ing.currentStock * ing.unitCost, 0);
  const criticalCount = ingredients.filter((ing) => ing.currentStock <= ing.minStock).length;

  const handleOpenRestock = (ing: Ingredient) => {
    setRestockItem(ing);
    setRestockQty(5);
    setRestockCost(ing.unitCost);
    setRestockSupplier(ing.supplier);
  };

  const handleConfirmRestock = (e: React.FormEvent) => {
    e.preventDefault();
    if (restockItem) {
      restockIngredient(restockItem.id, restockQty, restockCost, restockSupplier);
      setRestockItem(null);
    }
  };

  const handleCreateInsumo = (e: React.FormEvent) => {
    e.preventDefault();
    addIngredient(newInsumo);
    setIsAddOpen(false);
  };

  return (
    <div id="inventory-view" className="space-y-6">
      {/* Top Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs">
          <span className="text-xs font-bold text-stone-500 uppercase tracking-wider">
            Valor em Estoque (Custo)
          </span>
          <p className="text-2xl font-extrabold text-stone-900 font-['Outfit'] mt-1">
            {formatCurrency(totalStockValue)}
          </p>
          <p className="text-xs text-stone-500 mt-1">
            {ingredients.length} matérias-primas cadastradas
          </p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs">
          <span className="text-xs font-bold text-stone-500 uppercase tracking-wider">
            Itens Abaixo do Mínimo
          </span>
          <p className={`text-2xl font-extrabold font-['Outfit'] mt-1 ${criticalCount > 0 ? 'text-rose-600' : 'text-emerald-700'}`}>
            {criticalCount} {criticalCount === 1 ? 'insumo crítico' : 'insumos críticos'}
          </p>
          <p className="text-xs text-stone-500 mt-1">
            {criticalCount > 0 ? 'Reposição necessária para evitar paradas' : 'Estoque seguro'}
          </p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-stone-500 uppercase tracking-wider">
              Almoxarifado
            </span>
            <p className="text-xs text-stone-600 mt-1">Entrada de compras e controle</p>
          </div>
          <button
            id="btn-add-new-ingredient"
            onClick={() => setIsAddOpen(true)}
            className="px-4 py-2.5 bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center gap-1.5 shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Novo Insumo</span>
          </button>
        </div>
      </div>

      {/* Main Tab Controls & Search */}
      <div className="bg-white p-4 rounded-3xl border border-stone-200 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2 bg-stone-100 p-1 rounded-xl">
            <button
              onClick={() => setActiveTab('insumos')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                activeTab === 'insumos' ? 'bg-white text-stone-900 shadow-xs' : 'text-stone-600'
              }`}
            >
              Matérias-Primas & Insumos
            </button>
            <button
              onClick={() => setActiveTab('movimentacoes')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                activeTab === 'movimentacoes' ? 'bg-white text-stone-900 shadow-xs' : 'text-stone-600'
              }`}
            >
              Histórico de Movimentações ({stockMovements.length})
            </button>
          </div>

          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Buscar insumo ou fornecedor..."
              className="w-full pl-10 pr-4 py-2 rounded-xl bg-stone-50 border border-stone-200 text-stone-900 text-xs focus:outline-none focus:border-amber-500"
            />
          </div>
        </div>
      </div>

      {/* Tab 1: Insumos Table */}
      {activeTab === 'insumos' ? (
        <div className="bg-white rounded-3xl border border-stone-200 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-stone-700">
              <thead className="bg-stone-50 border-b border-stone-200 font-bold uppercase text-stone-500 tracking-wider">
                <tr>
                  <th className="py-3 px-4">Insumo / Matéria-Prima</th>
                  <th className="py-3 px-4">Categoria</th>
                  <th className="py-3 px-4 text-center">Estoque Atual</th>
                  <th className="py-3 px-4 text-right">Custo Unitário</th>
                  <th className="py-3 px-4">Fornecedor Principal</th>
                  <th className="py-3 px-4">Validade do Lote</th>
                  <th className="py-3 px-4 text-right">Ação</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {filteredIngredients.map((ing) => {
                  const isCritical = ing.currentStock <= ing.minStock;

                  return (
                    <tr key={ing.id} className="hover:bg-amber-50/30 transition-colors">
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2.5">
                          <div className={`w-2.5 h-2.5 rounded-full shrink-0 ${isCritical ? 'bg-rose-500 animate-pulse' : 'bg-emerald-500'}`} />
                          <span className="font-bold text-stone-900">{ing.name}</span>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-stone-500">{ing.category}</td>
                      <td className="py-3 px-4 text-center">
                        <span
                          className={`px-2.5 py-1 rounded-full font-mono font-bold text-[11px] ${
                            isCritical
                              ? 'bg-rose-100 text-rose-800 border border-rose-200'
                              : 'bg-stone-100 text-stone-800'
                          }`}
                        >
                          {ing.currentStock} {ing.unit} <span className="text-stone-400 font-normal">(Mín: {ing.minStock})</span>
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-stone-900">
                        {formatCurrency(ing.unitCost)}
                      </td>
                      <td className="py-3 px-4 text-stone-600">
                        <div className="flex items-center gap-1.5">
                          <Truck className="w-3.5 h-3.5 text-stone-400" />
                          <span>{ing.supplier}</span>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-stone-600">
                        <span className="font-mono text-[11px]">{ing.expiryDate}</span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          id={`btn-restock-${ing.id}`}
                          onClick={() => handleOpenRestock(ing)}
                          className="px-3 py-1.5 bg-amber-50 hover:bg-amber-500 hover:text-white text-amber-800 border border-amber-200 font-bold rounded-xl transition-all inline-flex items-center gap-1"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>Entrada</span>
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* Tab 2: Stock Movements History */
        <div className="bg-white rounded-3xl border border-stone-200 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-stone-700">
              <thead className="bg-stone-50 border-b border-stone-200 font-bold uppercase text-stone-500 tracking-wider">
                <tr>
                  <th className="py-3 px-4">Data / Hora</th>
                  <th className="py-3 px-4">Tipo</th>
                  <th className="py-3 px-4">Item / Insumo</th>
                  <th className="py-3 px-4 text-right">Quantidade</th>
                  <th className="py-3 px-4">Motivo / Documento</th>
                  <th className="py-3 px-4">Responsável</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {stockMovements.map((mov) => {
                  let badge = 'bg-stone-100 text-stone-800';
                  let label = 'Ajuste';
                  let Icon = ArrowUpRight;

                  if (mov.type === 'entrada') {
                    badge = 'bg-emerald-100 text-emerald-800 border border-emerald-200';
                    label = 'Entrada Compra';
                    Icon = ArrowDownRight;
                  } else if (mov.type === 'baixa_producao') {
                    badge = 'bg-amber-100 text-amber-800 border border-amber-200';
                    label = 'Baixa Produção';
                    Icon = ArrowUpRight;
                  } else if (mov.type === 'descarte_perda') {
                    badge = 'bg-rose-100 text-rose-800 border border-rose-200';
                    label = 'Perda / Descarte';
                    Icon = AlertTriangle;
                  }

                  return (
                    <tr key={mov.id} className="hover:bg-stone-50/50">
                      <td className="py-3 px-4 font-mono text-stone-500">{formatDateTime(mov.date)}</td>
                      <td className="py-3 px-4">
                        <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase ${badge}`}>
                          {label}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-bold text-stone-900">{mov.itemName}</td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-stone-900">
                        {mov.type === 'entrada' ? `+${mov.quantity}` : `-${mov.quantity}`} {mov.unit}
                      </td>
                      <td className="py-3 px-4 text-stone-600">{mov.reason || '-'}</td>
                      <td className="py-3 px-4 text-stone-500">{mov.user}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Quick Restock Entry Modal */}
      {restockItem && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 space-y-5 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div>
                <h3 className="font-bold text-base text-stone-900 font-['Outfit']">
                  Registrar Entrada de Estoque
                </h3>
                <p className="text-xs text-stone-500">{restockItem.name}</p>
              </div>
              <button
                onClick={() => setRestockItem(null)}
                className="p-1 rounded-lg text-stone-400 hover:text-stone-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleConfirmRestock} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Quantidade a Adicionar ({restockItem.unit}) *
                </label>
                <input
                  type="number"
                  step="1"
                  required
                  min="1"
                  value={restockQty}
                  onChange={(e) => setRestockQty(parseInt(e.target.value, 10) || 1)}
                  className="w-full px-3 py-2 text-sm font-mono font-bold rounded-xl border border-amber-300 focus:border-amber-500 focus:outline-none"
                />
                <p className="text-[11px] text-stone-400 mt-1">
                  Estoque atual: {restockItem.currentStock} {restockItem.unit} → Novo estoque: {restockItem.currentStock + restockQty} {restockItem.unit}
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Custo Unitário da Compra (R$)
                </label>
                <input
                  type="number"
                  step="0.10"
                  value={restockCost}
                  onChange={(e) => setRestockCost(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 text-xs font-mono rounded-xl border border-stone-200 focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Fornecedor / Nota Fiscal
                </label>
                <input
                  type="text"
                  value={restockSupplier}
                  onChange={(e) => setRestockSupplier(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-stone-200 focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setRestockItem(null)}
                  className="flex-1 py-2.5 rounded-xl border border-stone-300 text-stone-700 font-bold text-xs hover:bg-stone-100"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md"
                >
                  Confirmar Entrada
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add New Insumo Modal */}
      {isAddOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 space-y-5 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <h3 className="font-bold text-base text-stone-900 font-['Outfit']">
                Cadastrar Nova Matéria-Prima
              </h3>
              <button
                onClick={() => setIsAddOpen(false)}
                className="p-1 rounded-lg text-stone-400 hover:text-stone-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateInsumo} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Nome do Insumo *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Leite Integral Pasteurizado (Saco 1L)"
                  value={newInsumo.name}
                  onChange={(e) => setNewInsumo({ ...newInsumo, name: e.target.value })}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-stone-200 focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Categoria
                  </label>
                  <select
                    value={newInsumo.category}
                    onChange={(e) => setNewInsumo({ ...newInsumo, category: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-stone-200 focus:border-amber-500 focus:outline-none"
                  >
                    <option value="Farinhas & Grãos">Farinhas & Grãos</option>
                    <option value="Fermentos & Químicos">Fermentos & Químicos</option>
                    <option value="Laticínios">Laticínios</option>
                    <option value="Ovos">Ovos</option>
                    <option value="Açúcares & Doces">Açúcares & Doces</option>
                    <option value="Confeitaria">Confeitaria</option>
                    <option value="Embalagens">Embalagens</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Unidade
                  </label>
                  <select
                    value={newInsumo.unit}
                    onChange={(e) => setNewInsumo({ ...newInsumo, unit: e.target.value as any })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-stone-200 focus:border-amber-500 focus:outline-none"
                  >
                    <option value="un">Unidade (un / Saco / Caixa)</option>
                    <option value="kg">Quilo (kg)</option>
                    <option value="litro">Litro (L)</option>
                    <option value="g">Gramas (g)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Estoque Inicial
                  </label>
                  <input
                    type="number"
                    value={newInsumo.currentStock}
                    onChange={(e) => setNewInsumo({ ...newInsumo, currentStock: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 text-xs font-mono rounded-xl border border-stone-200 focus:border-amber-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Estoque Mínimo
                  </label>
                  <input
                    type="number"
                    value={newInsumo.minStock}
                    onChange={(e) => setNewInsumo({ ...newInsumo, minStock: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 text-xs font-mono rounded-xl border border-stone-200 focus:border-amber-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Custo Unit. (R$)
                  </label>
                  <input
                    type="number"
                    step="0.10"
                    value={newInsumo.unitCost}
                    onChange={(e) => setNewInsumo({ ...newInsumo, unitCost: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 text-xs font-mono rounded-xl border border-stone-200 focus:border-amber-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Fornecedor
                  </label>
                  <input
                    type="text"
                    value={newInsumo.supplier}
                    onChange={(e) => setNewInsumo({ ...newInsumo, supplier: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-stone-200 focus:border-amber-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Data de Validade
                  </label>
                  <input
                    type="date"
                    value={newInsumo.expiryDate}
                    onChange={(e) => setNewInsumo({ ...newInsumo, expiryDate: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-stone-200 focus:border-amber-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddOpen(false)}
                  className="flex-1 py-2.5 rounded-xl border border-stone-300 text-stone-700 font-bold text-xs hover:bg-stone-100"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs shadow-md"
                >
                  Salvar Matéria-Prima
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
