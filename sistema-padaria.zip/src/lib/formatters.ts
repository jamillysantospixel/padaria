export function formatCurrency(value: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  }).format(value || 0);
}

export function formatNumber(value: number, decimals: number = 2): string {
  return new Intl.NumberFormat('pt-BR', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  }).format(value || 0);
}

export function formatDateTime(dateString?: string): string {
  if (!dateString) return '-';
  try {
    const d = new Date(dateString.replace(' ', 'T'));
    if (isNaN(d.getTime())) return dateString;
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(d);
  } catch {
    return dateString;
  }
}

export function formatTime(dateString?: string): string {
  if (!dateString) return '-';
  if (dateString.length === 5 && dateString.includes(':')) return dateString;
  try {
    const d = new Date(dateString.replace(' ', 'T'));
    if (isNaN(d.getTime())) return dateString;
    return new Intl.DateTimeFormat('pt-BR', {
      hour: '2-digit',
      minute: '2-digit',
    }).format(d);
  } catch {
    return dateString;
  }
}

export function getCategoryLabel(category: string): string {
  const map: Record<string, string> = {
    paes: 'Pães & Broas',
    confeitaria: 'Confeitaria & Bolos',
    salgados: 'Salgados & Lanches',
    bebidas: 'Bebidas & Cafeteria',
    frios: 'Frios & Laticínios',
    mercearia: 'Mercearia',
    insumos: 'Matérias-Primas',
  };
  return map[category] || category;
}

export function getPaymentMethodLabel(method: string): string {
  const map: Record<string, string> = {
    dinheiro: 'Dinheiro',
    pix: 'PIX Instantâneo',
    debito: 'Cartão de Débito',
    credito: 'Cartão de Crédito',
    fiado: 'Caderneta / Fiado',
    vale_refeicao: 'Vale Refeição / Alimentação',
  };
  return map[method] || method;
}
