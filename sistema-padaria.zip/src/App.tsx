import React, { useState } from 'react';
import { BakeryProvider, useBakery } from './context/BakeryContext';
import { LoginScreen } from './components/auth/LoginScreen';
import { Sidebar, NavigationTab } from './components/layout/Sidebar';
import { Header } from './components/layout/Header';
import { ToastContainer } from './components/layout/ToastContainer';
import { AiAssistantModal } from './components/layout/AiAssistantModal';
import { DashboardView } from './components/dashboard/DashboardView';
import { PDVView } from './components/pdv/PDVView';
import { ProductsView } from './components/products/ProductsView';
import { InventoryView } from './components/inventory/InventoryView';
import { BatchesView } from './components/batches/BatchesView';
import { CashRegisterView } from './components/cash/CashRegisterView';
import { CustomersView } from './components/customers/CustomersView';
import { EmployeesView } from './components/employees/EmployeesView';
import { ReportsView } from './components/reports/ReportsView';

const MainLayout: React.FC = () => {
  const { currentUser } = useBakery();
  const [activeTab, setActiveTab] = useState<NavigationTab>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [isAiModalOpen, setIsAiModalOpen] = useState(false);

  if (!currentUser) {
    return <LoginScreen />;
  }

  const renderActiveView = () => {
    switch (activeTab) {
      case 'dashboard':
        return <DashboardView setActiveTab={setActiveTab} openAiModal={() => setIsAiModalOpen(true)} />;
      case 'pdv':
        return <PDVView />;
      case 'produtos':
        return <ProductsView />;
      case 'estoque':
        return <InventoryView />;
      case 'fornadas':
        return <BatchesView />;
      case 'caixa':
        return <CashRegisterView />;
      case 'clientes':
        return <CustomersView />;
      case 'funcionarios':
        return <EmployeesView />;
      case 'relatorios':
        return <ReportsView />;
      default:
        return <DashboardView setActiveTab={setActiveTab} openAiModal={() => setIsAiModalOpen(true)} />;
    }
  };

  return (
    <div className="flex h-screen bg-[#F8F7F4] text-stone-800 font-['Plus_Jakarta_Sans',sans-serif] overflow-hidden antialiased selection:bg-amber-200 selection:text-amber-900">
      {/* Navigation Sidebar */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isOpen={sidebarOpen}
        setIsOpen={setSidebarOpen}
        openAiModal={() => setIsAiModalOpen(true)}
      />

      {/* Main App Container */}
      <div className={`flex-1 flex flex-col min-w-0 overflow-hidden transition-all duration-300 ${sidebarOpen ? 'md:ml-64 ml-20' : 'ml-20'}`}>
        {/* Top Header Bar */}
        <Header
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          sidebarOpen={sidebarOpen}
          setSidebarOpen={setSidebarOpen}
          openAiModal={() => setIsAiModalOpen(true)}
        />

        {/* Scrollable Workspace Area */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 custom-scrollbar">
          <div className="max-w-7xl mx-auto pb-12">
            {renderActiveView()}
          </div>
        </main>
      </div>

      {/* AI Assistant Modal */}
      <AiAssistantModal
        isOpen={isAiModalOpen}
        onClose={() => setIsAiModalOpen(false)}
      />

      {/* Real-time Toast Notifications */}
      <ToastContainer />
    </div>
  );
};

export function App() {
  return (
    <BakeryProvider>
      <MainLayout />
    </BakeryProvider>
  );
}

export default App;
