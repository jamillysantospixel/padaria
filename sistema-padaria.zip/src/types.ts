export type UserRole = 'admin' | 'padeiro' | 'caixa' | 'gerente';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar: string;
  shift?: string;
}

export type ProductCategory = 
  | 'paes' 
  | 'confeitaria' 
  | 'salgados' 
  | 'bebidas' 
  | 'frios' 
  | 'mercearia' 
  | 'insumos';

export interface Product {
  id: string;
  code: string; // Barcode or PLU (e.g. 101)
  name: string;
  category: ProductCategory;
  unit: 'un' | 'kg' | 'cento' | 'fatia' | 'litro';
  price: number; // Selling price
  cost: number; // Production/Purchase cost
  stock: number; // Current stock count or kg
  minStock: number; // Minimum stock threshold
  image: string;
  description?: string;
  recipeIngredients?: { ingredientId: string; amountNeeded: number; unit: string }[];
  isBakeryProduced: boolean; // Produced in-house (Pão, Bolo, Salgado)
  active: boolean;
}

export interface Ingredient {
  id: string;
  name: string;
  category: string;
  currentStock: number;
  minStock: number;
  unit: 'kg' | 'g' | 'litro' | 'ml' | 'un';
  unitCost: number;
  supplier: string;
  expiryDate: string;
  lastRestockDate: string;
}

export interface StockMovement {
  id: string;
  itemId: string;
  itemName: string;
  type: 'entrada' | 'saida_venda' | 'baixa_producao' | 'descarte_perda' | 'ajuste';
  quantity: number;
  unit: string;
  date: string;
  user: string;
  reason?: string;
  costImpact?: number;
}

export interface CartItem {
  product: Product;
  quantity: number; // can be float for kg (e.g. 0.450 kg)
  unitPrice: number;
  totalPrice: number;
  notes?: string;
}

export type PaymentMethod = 'dinheiro' | 'pix' | 'debito' | 'credito' | 'fiado' | 'vale_refeicao';

export interface Sale {
  id: string;
  saleNumber: number;
  date: string;
  cashierName: string;
  customerId?: string;
  customerName?: string;
  items: CartItem[];
  subtotal: number;
  discount: number; // discount amount in R$
  total: number;
  paymentMethod: PaymentMethod;
  amountPaid?: number;
  change?: number; // troco
  comandaNumber?: number;
  status: 'concluida' | 'cancelada';
}

export interface CashRegisterMovement {
  id: string;
  type: 'suprimento' | 'sangria' | 'venda';
  amount: number;
  paymentMethod?: PaymentMethod;
  timestamp: string;
  description: string;
  operatorName: string;
}

export interface CashRegisterShift {
  id: string;
  status: 'aberto' | 'fechado';
  openedAt: string;
  closedAt?: string;
  openedBy: string;
  closedBy?: string;
  initialAmount: number; // Fundo de troco
  finalAmountCalculated?: number;
  finalAmountReported?: number; // Contado pelo caixa
  difference?: number; // Quebra de caixa
  movements: CashRegisterMovement[];
  salesCount: number;
  totalSales: number;
  notes?: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  email?: string;
  cpf?: string;
  loyaltyPoints: number;
  creditLimit: number; // Limite de fiado
  creditBalance: number; // Saldo devedor atual
  notes?: string;
  createdAt: string;
  lastPurchaseDate?: string;
  purchaseCount: number;
  totalSpent: number;
}

export interface Employee {
  id: string;
  name: string;
  role: UserRole;
  roleTitle: string;
  phone: string;
  email: string;
  shift: 'manha' | 'tarde' | 'noite' | 'integral';
  shiftHours: string;
  salary: number;
  status: 'ativo' | 'folga' | 'ferias';
  hireDate: string;
  avatar: string;
}

export type BatchStatus = 'preparando' | 'fermentando' | 'assando' | 'pronto' | 'esgotado';

export interface BakeryBatch {
  id: string;
  batchCode: string;
  productName: string;
  productId: string;
  plannedQuantity: number;
  unit: string;
  status: BatchStatus;
  bakerName: string;
  startedAt: string;
  readyAtEstimated: string;
  finishedAt?: string;
  actualProduced?: number;
  wastedQuantity?: number; // Perdas na fornada
  wasteReason?: string;
  temperatureTarget?: number; // 200°C
}

export interface DailyReportSummary {
  date: string;
  totalRevenue: number;
  totalCost: number;
  grossProfit: number;
  ordersCount: number;
  averageTicket: number;
  totalWasteCost: number;
  topSellingProducts: { name: string; quantity: number; revenue: number }[];
  salesByHour: { hour: string; total: number; orders: number }[];
  salesByCategory: { category: string; total: number; percentage: number }[];
}
