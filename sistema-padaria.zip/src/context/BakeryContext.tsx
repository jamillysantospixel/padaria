import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  User, Product, Ingredient, StockMovement, CartItem, Sale, 
  CashRegisterShift, Customer, Employee, BakeryBatch, CashRegisterMovement, PaymentMethod 
} from '../types';
import { 
  INITIAL_USERS, INITIAL_PRODUCTS, INITIAL_INGREDIENTS, 
  INITIAL_CUSTOMERS, INITIAL_EMPLOYEES, INITIAL_BATCHES, 
  INITIAL_SALES, INITIAL_CASH_REGISTER 
} from '../data/initialData';
import { sounds } from '../lib/audio';
import confetti from 'canvas-confetti';

interface ToastNotification {
  id: string;
  type: 'success' | 'warning' | 'error' | 'info';
  title: string;
  message: string;
}

interface BakeryContextType {
  currentUser: User | null;
  users: User[];
  loginAs: (user: User) => void;
  logout: () => void;

  products: Product[];
  addProduct: (product: Omit<Product, 'id'>) => void;
  updateProduct: (id: string, updates: Partial<Product>) => void;
  deleteProduct: (id: string) => void;

  ingredients: Ingredient[];
  addIngredient: (ingredient: Omit<Ingredient, 'id'>) => void;
  restockIngredient: (id: string, quantity: number, unitCost: number, supplier?: string) => void;
  stockMovements: StockMovement[];

  cart: CartItem[];
  addToCart: (product: Product, quantity?: number) => void;
  updateCartItemQuantity: (productId: string, quantity: number) => void;
  removeFromCart: (productId: string) => void;
  clearCart: () => void;
  checkoutSale: (
    paymentMethod: PaymentMethod, 
    discount: number, 
    amountPaid?: number, 
    customerId?: string,
    comandaNumber?: number
  ) => Sale | null;

  sales: Sale[];
  cancelSale: (saleId: string) => void;

  cashRegister: CashRegisterShift;
  openCashRegister: (initialAmount: number, notes?: string) => void;
  closeCashRegister: (finalAmountReported: number, notes?: string) => void;
  addCashMovement: (type: 'suprimento' | 'sangria', amount: number, description: string) => void;

  customers: Customer[];
  addCustomer: (customer: Omit<Customer, 'id' | 'loyaltyPoints' | 'creditBalance' | 'purchaseCount' | 'totalSpent' | 'createdAt'>) => void;
  updateCustomer: (id: string, updates: Partial<Customer>) => void;
  payCustomerDebt: (customerId: string, amount: number) => void;

  employees: Employee[];
  addEmployee: (employee: Omit<Employee, 'id'>) => void;
  updateEmployee: (id: string, updates: Partial<Employee>) => void;

  batches: BakeryBatch[];
  addBatch: (batch: Omit<BakeryBatch, 'id' | 'batchCode' | 'startedAt'>) => void;
  advanceBatchStatus: (batchId: string, actualProduced?: number, wastedQuantity?: number, wasteReason?: string) => void;

  toasts: ToastNotification[];
  addToast: (type: ToastNotification['type'], title: string, message: string) => void;
  removeToast: (id: string) => void;

  resetDemoData: () => void;
}

const BakeryContext = createContext<BakeryContextType | undefined>(undefined);

const STORAGE_KEYS = {
  USER: 'sp_current_user',
  PRODUCTS: 'sp_products',
  INGREDIENTS: 'sp_ingredients',
  MOVEMENTS: 'sp_stock_movements',
  SALES: 'sp_sales',
  CASH: 'sp_cash_register',
  CUSTOMERS: 'sp_customers',
  EMPLOYEES: 'sp_employees',
  BATCHES: 'sp_batches',
};

export const BakeryProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load initial states from localStorage or defaults
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.USER);
    return saved ? JSON.parse(saved) : INITIAL_USERS[0]; // Auto-login first user for instant preview experience
  });

  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.PRODUCTS);
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });

  const [ingredients, setIngredients] = useState<Ingredient[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.INGREDIENTS);
    return saved ? JSON.parse(saved) : INITIAL_INGREDIENTS;
  });

  const [stockMovements, setStockMovements] = useState<StockMovement[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.MOVEMENTS);
    return saved ? JSON.parse(saved) : [
      {
        id: 'mov-init-1',
        itemId: 'ing-1',
        itemName: 'Farinha de Trigo Especial Tipo 1',
        type: 'entrada',
        quantity: 20,
        unit: 'un',
        date: '2026-08-18 10:00',
        user: 'Carlos Mendes',
        reason: 'Compra de Reposição NF 4421',
      },
      {
        id: 'mov-init-2',
        itemId: 'ing-2',
        itemName: 'Fermento Biológico Fresco',
        type: 'baixa_producao',
        quantity: 4,
        unit: 'un',
        date: '2026-08-24 05:00',
        user: 'Arnaldo Ribeiro',
        reason: 'Fornadas da Manhã Pão Francês',
      }
    ];
  });

  const [sales, setSales] = useState<Sale[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SALES);
    return saved ? JSON.parse(saved) : INITIAL_SALES;
  });

  const [cart, setCart] = useState<CartItem[]>([]);

  const [cashRegister, setCashRegister] = useState<CashRegisterShift>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CASH);
    return saved ? JSON.parse(saved) : INITIAL_CASH_REGISTER;
  });

  const [customers, setCustomers] = useState<Customer[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CUSTOMERS);
    return saved ? JSON.parse(saved) : INITIAL_CUSTOMERS;
  });

  const [employees, setEmployees] = useState<Employee[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.EMPLOYEES);
    return saved ? JSON.parse(saved) : INITIAL_EMPLOYEES;
  });

  const [batches, setBatches] = useState<BakeryBatch[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.BATCHES);
    return saved ? JSON.parse(saved) : INITIAL_BATCHES;
  });

  const [toasts, setToasts] = useState<ToastNotification[]>([]);

  // Sync to local storage
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(currentUser));
    } else {
      localStorage.removeItem(STORAGE_KEYS.USER);
    }
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.INGREDIENTS, JSON.stringify(ingredients));
  }, [ingredients]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.MOVEMENTS, JSON.stringify(stockMovements));
  }, [stockMovements]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SALES, JSON.stringify(sales));
  }, [sales]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CASH, JSON.stringify(cashRegister));
  }, [cashRegister]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(customers));
  }, [customers]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.EMPLOYEES, JSON.stringify(employees));
  }, [employees]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.BATCHES, JSON.stringify(batches));
  }, [batches]);

  const addToast = (type: ToastNotification['type'], title: string, message: string) => {
    const id = 'toast-' + Date.now() + '-' + Math.random().toString(36).substr(2, 4);
    setToasts((prev) => [...prev, { id, type, title, message }]);
    setTimeout(() => {
      removeToast(id);
    }, 4500);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const loginAs = (user: User) => {
    setCurrentUser(user);
    addToast('success', 'Bem-vindo(a)!', `Conectado como ${user.name} (${user.role.toUpperCase()})`);
  };

  const logout = () => {
    setCurrentUser(null);
    addToast('info', 'Sessão Encerrada', 'Você saiu do sistema.');
  };

  // Cart operations
  const addToCart = (product: Product, quantity = 1) => {
    sounds.playBeep();
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        const newQty = existing.quantity + quantity;
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: newQty, totalPrice: newQty * item.unitPrice }
            : item
        );
      } else {
        return [
          ...prev,
          {
            product,
            quantity,
            unitPrice: product.price,
            totalPrice: quantity * product.price,
          },
        ];
      }
    });
  };

  const updateCartItemQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) =>
        item.product.id === productId
          ? { ...item, quantity, totalPrice: quantity * item.unitPrice }
          : item
      )
    );
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const clearCart = () => {
    setCart([]);
  };

  const checkoutSale = (
    paymentMethod: PaymentMethod,
    discount: number,
    amountPaid?: number,
    customerId?: string,
    comandaNumber?: number
  ): Sale | null => {
    if (cart.length === 0) {
      addToast('error', 'Carrinho Vazio', 'Adicione produtos antes de finalizar a venda.');
      return null;
    }

    const subtotal = cart.reduce((acc, item) => acc + item.totalPrice, 0);
    const total = Math.max(0, subtotal - discount);
    const change = amountPaid && amountPaid > total ? amountPaid - total : 0;

    let customerName = undefined;
    if (customerId) {
      const cust = customers.find((c) => c.id === customerId);
      if (cust) {
        customerName = cust.name;
        // If paid by fiado, update customer creditBalance
        if (paymentMethod === 'fiado') {
          if (cust.creditBalance + total > cust.creditLimit) {
            addToast(
              'warning',
              'Limite de Fiado Excedido',
              `O cliente ${cust.name} ultrapassará o limite de R$ ${cust.creditLimit.toFixed(2)}.`
            );
          }
          setCustomers((prev) =>
            prev.map((c) =>
              c.id === customerId
                ? {
                    ...c,
                    creditBalance: c.creditBalance + total,
                    loyaltyPoints: c.loyaltyPoints + Math.floor(total),
                    purchaseCount: c.purchaseCount + 1,
                    totalSpent: c.totalSpent + total,
                    lastPurchaseDate: new Date().toISOString().split('T')[0],
                  }
                : c
            )
          );
        } else {
          // Regular payment with loyalty points earned
          setCustomers((prev) =>
            prev.map((c) =>
              c.id === customerId
                ? {
                    ...c,
                    loyaltyPoints: c.loyaltyPoints + Math.floor(total),
                    purchaseCount: c.purchaseCount + 1,
                    totalSpent: c.totalSpent + total,
                    lastPurchaseDate: new Date().toISOString().split('T')[0],
                  }
                : c
            )
          );
        }
      }
    }

    const newSaleNumber = sales.length > 0 ? Math.max(...sales.map((s) => s.saleNumber)) + 1 : 1001;
    const nowStr = new Date().toISOString().replace('T', ' ').substring(0, 16);

    const newSale: Sale = {
      id: 'sale-' + Date.now(),
      saleNumber: newSaleNumber,
      date: nowStr,
      cashierName: currentUser?.name || 'Operador',
      customerId,
      customerName,
      items: [...cart],
      subtotal,
      discount,
      total,
      paymentMethod,
      amountPaid: amountPaid || total,
      change,
      comandaNumber,
      status: 'concluida',
    };

    // Deduct stock for sold items
    setProducts((prev) =>
      prev.map((p) => {
        const cartItem = cart.find((ci) => ci.product.id === p.id);
        if (cartItem) {
          const newStock = Math.max(0, p.stock - cartItem.quantity);
          return { ...p, stock: Number(newStock.toFixed(2)) };
        }
        return p;
      })
    );

    // Update cash register if register is open
    if (cashRegister.status === 'aberto') {
      const newCashMov: CashRegisterMovement = {
        id: 'mov-' + Date.now(),
        type: 'venda',
        amount: total,
        paymentMethod,
        timestamp: nowStr,
        description: `Venda #${newSaleNumber} (${paymentMethod.toUpperCase()})`,
        operatorName: currentUser?.name || 'Caixa',
      };

      setCashRegister((prev) => ({
        ...prev,
        totalSales: prev.totalSales + total,
        salesCount: prev.salesCount + 1,
        movements: [...prev.movements, newCashMov],
      }));
    }

    setSales((prev) => [newSale, ...prev]);
    setCart([]);

    sounds.playCashRegister();
    try {
      confetti({
        particleCount: 45,
        spread: 60,
        origin: { y: 0.8 },
        colors: ['#f59e0b', '#d97706', '#10b981', '#3b82f6'],
      });
    } catch {
      // ignore
    }

    addToast('success', 'Venda Finalizada!', `Venda #${newSaleNumber} concluída com sucesso.`);
    return newSale;
  };

  const cancelSale = (saleId: string) => {
    const sale = sales.find((s) => s.id === saleId);
    if (!sale) return;

    // Restore stock
    setProducts((prev) =>
      prev.map((p) => {
        const item = sale.items.find((i) => i.product.id === p.id);
        if (item) {
          return { ...p, stock: Number((p.stock + item.quantity).toFixed(2)) };
        }
        return p;
      })
    );

    setSales((prev) =>
      prev.map((s) => (s.id === saleId ? { ...s, status: 'cancelada' } : s))
    );

    addToast('info', 'Venda Cancelada', `Venda #${sale.saleNumber} foi marcada como cancelada.`);
  };

  // Products
  const addProduct = (prodData: Omit<Product, 'id'>) => {
    const newProd: Product = {
      ...prodData,
      id: 'prod-' + Date.now(),
    };
    setProducts((prev) => [newProd, ...prev]);
    addToast('success', 'Produto Criado', `"${newProd.name}" cadastrado com sucesso.`);
  };

  const updateProduct = (id: string, updates: Partial<Product>) => {
    setProducts((prev) => prev.map((p) => (p.id === id ? { ...p, ...updates } : p)));
    addToast('success', 'Produto Atualizado', 'As alterações foram salvas.');
  };

  const deleteProduct = (id: string) => {
    const prod = products.find((p) => p.id === id);
    setProducts((prev) => prev.filter((p) => p.id !== id));
    addToast('info', 'Produto Removido', `Produto ${prod?.name || ''} excluído.`);
  };

  // Ingredients & Stock
  const addIngredient = (ingData: Omit<Ingredient, 'id'>) => {
    const newIng: Ingredient = {
      ...ingData,
      id: 'ing-' + Date.now(),
    };
    setIngredients((prev) => [newIng, ...prev]);
    addToast('success', 'Insumo Adicionado', `${newIng.name} inserido no estoque.`);
  };

  const restockIngredient = (id: string, quantity: number, unitCost: number, supplier?: string) => {
    const ing = ingredients.find((i) => i.id === id);
    if (!ing) return;

    const todayStr = new Date().toISOString().replace('T', ' ').substring(0, 16);

    setIngredients((prev) =>
      prev.map((item) =>
        item.id === id
          ? {
              ...item,
              currentStock: item.currentStock + quantity,
              unitCost: unitCost > 0 ? unitCost : item.unitCost,
              supplier: supplier || item.supplier,
              lastRestockDate: todayStr.split(' ')[0],
            }
          : item
      )
    );

    const mov: StockMovement = {
      id: 'mov-' + Date.now(),
      itemId: id,
      itemName: ing.name,
      type: 'entrada',
      quantity,
      unit: ing.unit,
      date: todayStr,
      user: currentUser?.name || 'Almoxarife',
      reason: `Entrada de Reposição (${supplier || 'Fornecedor padrão'})`,
      costImpact: quantity * (unitCost || ing.unitCost),
    };

    setStockMovements((prev) => [mov, ...prev]);
    addToast('success', 'Estoque Atualizado', `+${quantity} ${ing.unit} de ${ing.name} registrados.`);
  };

  // Cash Register
  const openCashRegister = (initialAmount: number, notes?: string) => {
    const nowStr = new Date().toISOString().replace('T', ' ').substring(0, 16);
    const newShift: CashRegisterShift = {
      id: 'shift-' + Date.now(),
      status: 'aberto',
      openedAt: nowStr,
      openedBy: currentUser?.name || 'Operador',
      initialAmount,
      movements: [],
      salesCount: 0,
      totalSales: 0,
      notes,
    };
    setCashRegister(newShift);
    addToast('success', 'Caixa Aberto', `Caixa aberto com fundo inicial de R$ ${initialAmount.toFixed(2)}.`);
  };

  const closeCashRegister = (finalAmountReported: number, notes?: string) => {
    const nowStr = new Date().toISOString().replace('T', ' ').substring(0, 16);
    // Calculate expected total in register: initial + suprimento - sangria + cash sales
    const totalSuprimento = cashRegister.movements
      .filter((m) => m.type === 'suprimento')
      .reduce((a, b) => a + b.amount, 0);
    const totalSangria = cashRegister.movements
      .filter((m) => m.type === 'sangria')
      .reduce((a, b) => a + b.amount, 0);
    const cashSales = cashRegister.movements
      .filter((m) => m.type === 'venda' && m.paymentMethod === 'dinheiro')
      .reduce((a, b) => a + b.amount, 0);

    const expectedCashInDrawer = cashRegister.initialAmount + totalSuprimento - totalSangria + cashSales;
    const difference = finalAmountReported - expectedCashInDrawer;

    setCashRegister((prev) => ({
      ...prev,
      status: 'fechado',
      closedAt: nowStr,
      closedBy: currentUser?.name || 'Operador',
      finalAmountCalculated: expectedCashInDrawer,
      finalAmountReported,
      difference,
      notes,
    }));

    addToast(
      difference === 0 ? 'success' : difference > 0 ? 'info' : 'warning',
      'Fechamento de Caixa',
      `Caixa fechado. Diferença: R$ ${difference.toFixed(2)}`
    );
  };

  const addCashMovement = (type: 'suprimento' | 'sangria', amount: number, description: string) => {
    const nowStr = new Date().toISOString().replace('T', ' ').substring(0, 16);
    const newMov: CashRegisterMovement = {
      id: 'mov-' + Date.now(),
      type,
      amount,
      timestamp: nowStr,
      description,
      operatorName: currentUser?.name || 'Operador',
    };

    setCashRegister((prev) => ({
      ...prev,
      movements: [...prev.movements, newMov],
    }));

    addToast(
      'success',
      type === 'suprimento' ? 'Suprimento Registrado' : 'Sangria Realizada',
      `R$ ${amount.toFixed(2)} registrado com sucesso.`
    );
  };

  // Customers
  const addCustomer = (custData: Omit<Customer, 'id' | 'loyaltyPoints' | 'creditBalance' | 'purchaseCount' | 'totalSpent' | 'createdAt'>) => {
    const newCust: Customer = {
      ...custData,
      id: 'cust-' + Date.now(),
      loyaltyPoints: 0,
      creditBalance: 0,
      purchaseCount: 0,
      totalSpent: 0,
      createdAt: new Date().toISOString().split('T')[0],
    };
    setCustomers((prev) => [newCust, ...prev]);
    addToast('success', 'Cliente Cadastrado', `${newCust.name} adicionado ao sistema.`);
  };

  const updateCustomer = (id: string, updates: Partial<Customer>) => {
    setCustomers((prev) => prev.map((c) => (c.id === id ? { ...c, ...updates } : c)));
    addToast('success', 'Cliente Atualizado', 'Dados do cliente salvos.');
  };

  const payCustomerDebt = (customerId: string, amount: number) => {
    const cust = customers.find((c) => c.id === customerId);
    if (!cust) return;
    const newBalance = Math.max(0, cust.creditBalance - amount);
    setCustomers((prev) =>
      prev.map((c) => (c.id === customerId ? { ...c, creditBalance: newBalance } : c))
    );

    // Register in cash
    if (cashRegister.status === 'aberto') {
      addCashMovement('suprimento', amount, `Pagamento de Fiado - Cliente: ${cust.name}`);
    }

    addToast('success', 'Pagamento Recebido', `R$ ${amount.toFixed(2)} amortizado da conta de ${cust.name}.`);
  };

  // Employees
  const addEmployee = (empData: Omit<Employee, 'id'>) => {
    const newEmp: Employee = {
      ...empData,
      id: 'emp-' + Date.now(),
    };
    setEmployees((prev) => [newEmp, ...prev]);
    addToast('success', 'Colaborador Cadastrado', `${newEmp.name} adicionado à equipe.`);
  };

  const updateEmployee = (id: string, updates: Partial<Employee>) => {
    setEmployees((prev) => prev.map((e) => (e.id === id ? { ...e, ...updates } : e)));
    addToast('success', 'Colaborador Atualizado', 'Informações da equipe salvas.');
  };

  // Bakery Batches / Fornadas
  const addBatch = (batchData: Omit<BakeryBatch, 'id' | 'batchCode' | 'startedAt'>) => {
    const count = batches.length + 1;
    const now = new Date();
    const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    const code = `FORN-${now.getMonth() + 1}${now.getDate()}-${String(count).padStart(2, '0')}`;

    const newBatch: BakeryBatch = {
      ...batchData,
      id: 'batch-' + Date.now(),
      batchCode: code,
      startedAt: timeStr,
    };

    setBatches((prev) => [newBatch, ...prev]);
    addToast('success', 'Fornada Iniciada', `Fornada ${code} (${newBatch.productName}) em andamento!`);
  };

  const advanceBatchStatus = (
    batchId: string,
    actualProduced?: number,
    wastedQuantity?: number,
    wasteReason?: string
  ) => {
    const batch = batches.find((b) => b.id === batchId);
    if (!batch) return;

    let nextStatus = batch.status;
    if (batch.status === 'preparando') nextStatus = 'fermentando';
    else if (batch.status === 'fermentando') nextStatus = 'assando';
    else if (batch.status === 'assando') {
      nextStatus = 'pronto';
      sounds.playOvenBell();
      addToast('success', '🥖 Fornada Pronta!', `${batch.productName} quentinho saindo do forno!`);
    } else if (batch.status === 'pronto') {
      nextStatus = 'esgotado';
    }

    const now = new Date();
    const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

    setBatches((prev) =>
      prev.map((b) =>
        b.id === batchId
          ? {
              ...b,
              status: nextStatus,
              finishedAt: nextStatus === 'pronto' ? timeStr : b.finishedAt,
              actualProduced: actualProduced !== undefined ? actualProduced : (nextStatus === 'pronto' ? b.plannedQuantity : b.actualProduced),
              wastedQuantity: wastedQuantity !== undefined ? wastedQuantity : b.wastedQuantity,
              wasteReason: wasteReason || b.wasteReason,
            }
          : b
      )
    );

    // If batch is ready, increment the product stock
    if (nextStatus === 'pronto' && batch.status !== 'pronto') {
      const producedQty = actualProduced ?? batch.plannedQuantity;
      setProducts((prev) =>
        prev.map((p) =>
          p.id === batch.productId
            ? { ...p, stock: Number((p.stock + producedQty).toFixed(2)) }
            : p
        )
      );
    }
  };

  const resetDemoData = () => {
    setProducts(INITIAL_PRODUCTS);
    setIngredients(INITIAL_INGREDIENTS);
    setCustomers(INITIAL_CUSTOMERS);
    setEmployees(INITIAL_EMPLOYEES);
    setBatches(INITIAL_BATCHES);
    setSales(INITIAL_SALES);
    setCashRegister(INITIAL_CASH_REGISTER);
    setCart([]);
    addToast('info', 'Dados Restaurados', 'Base de dados restaurada para o padrão inicial de demonstração.');
  };

  return (
    <BakeryContext.Provider
      value={{
        currentUser,
        users: INITIAL_USERS,
        loginAs,
        logout,
        products,
        addProduct,
        updateProduct,
        deleteProduct,
        ingredients,
        addIngredient,
        restockIngredient,
        stockMovements,
        cart,
        addToCart,
        updateCartItemQuantity,
        removeFromCart,
        clearCart,
        checkoutSale,
        sales,
        cancelSale,
        cashRegister,
        openCashRegister,
        closeCashRegister,
        addCashMovement,
        customers,
        addCustomer,
        updateCustomer,
        payCustomerDebt,
        employees,
        addEmployee,
        updateEmployee,
        batches,
        addBatch,
        advanceBatchStatus,
        toasts,
        addToast,
        removeToast,
        resetDemoData,
      }}
    >
      {children}
    </BakeryContext.Provider>
  );
};

export const useBakery = () => {
  const context = useContext(BakeryContext);
  if (!context) {
    throw new Error('useBakery must be used within a BakeryProvider');
  }
  return context;
};
